import { useState, useEffect, useCallback, useRef } from 'react';
import type { Question } from '../data/questions';

export interface QuizAnswer {
  questionId: string;
  selectedIndex: number;
  isCorrect: boolean;
}

export type AnswerMap = Record<string, number | null>;
export type ReviewSet = Set<string>;

interface UseQuizOptions {
  questions: Question[];
  timeLimitSeconds: number;
  onTimeUp?: () => void;
}

export function useQuiz({ questions, timeLimitSeconds, onTimeUp }: UseQuizOptions) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<AnswerMap>({});
  const [markedForReview, setMarkedForReview] = useState<string[]>([]);
  const [timeRemaining, setTimeRemaining] = useState(timeLimitSeconds);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isStarted, setIsStarted] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startQuiz = useCallback(() => {
    setIsStarted(true);
    setStartTime(Date.now());
  }, []);

  const submitQuiz = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsSubmitted(true);
  }, []);

  useEffect(() => {
    if (!isStarted || isSubmitted) return;
    timerRef.current = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          setIsSubmitted(true);
          onTimeUp?.();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isStarted, isSubmitted, onTimeUp]);

  const selectAnswer = useCallback((questionId: string, optionIndex: number) => {
    if (isSubmitted) return;
    const q = questions.find(q => q.id === questionId);
    setAnswers(prev => ({ ...prev, [questionId]: optionIndex }));
    if (q && !q) return; // linter
  }, [isSubmitted, questions]);

  const toggleMarkForReview = useCallback((questionId: string) => {
    setMarkedForReview(prev =>
      prev.includes(questionId) ? prev.filter(id => id !== questionId) : [...prev, questionId]
    );
  }, []);

  const navigateTo = useCallback((index: number) => {
    if (index >= 0 && index < questions.length) setCurrentIndex(index);
  }, [questions.length]);

  const nextQuestion = useCallback(() => {
    setCurrentIndex(prev => Math.min(prev + 1, questions.length - 1));
  }, [questions.length]);

  const prevQuestion = useCallback(() => {
    setCurrentIndex(prev => Math.max(prev - 1, 0));
  }, []);

  const getTimeTaken = () => {
    if (!startTime) return timeLimitSeconds - timeRemaining;
    return Math.round((Date.now() - startTime) / 1000);
  };

  return {
    currentIndex,
    currentQuestion: questions[currentIndex],
    answers,
    markedForReview,
    timeRemaining,
    isSubmitted,
    isStarted,
    selectAnswer,
    toggleMarkForReview,
    navigateTo,
    nextQuestion,
    prevQuestion,
    submitQuiz,
    startQuiz,
    getTimeTaken,
  };
}
