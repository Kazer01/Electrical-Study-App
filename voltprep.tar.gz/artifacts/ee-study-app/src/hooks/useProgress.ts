import { useLocalStorage } from './useLocalStorage';
import { STORAGE_KEYS } from '../utils/storage';
import type { SubjectId } from '../data/questions';

export interface SubjectProgress {
  attempted: number;
  correct: number;
  totalTime: number;
}

export type ProgressMap = Partial<Record<SubjectId, SubjectProgress>>;

export function useProgress() {
  const [progress, setProgress] = useLocalStorage<ProgressMap>(STORAGE_KEYS.PROGRESS, {});

  const recordAttempt = (
    subject: SubjectId,
    correct: number,
    total: number,
    timeTaken: number
  ) => {
    setProgress(prev => {
      const existing = prev[subject] ?? { attempted: 0, correct: 0, totalTime: 0 };
      return {
        ...prev,
        [subject]: {
          attempted: existing.attempted + total,
          correct: existing.correct + correct,
          totalTime: existing.totalTime + timeTaken,
        },
      };
    });
  };

  const getSubjectStats = (subject: SubjectId): SubjectProgress => {
    return progress[subject] ?? { attempted: 0, correct: 0, totalTime: 0 };
  };

  const getOverallStats = () => {
    let totalAttempted = 0, totalCorrect = 0, totalTime = 0;
    for (const s of Object.values(progress)) {
      if (!s) continue;
      totalAttempted += s.attempted;
      totalCorrect += s.correct;
      totalTime += s.totalTime;
    }
    const accuracy = totalAttempted > 0 ? Math.round((totalCorrect / totalAttempted) * 100) : 0;
    return { totalAttempted, totalCorrect, totalTime, accuracy };
  };

  const resetProgress = () => setProgress({});

  return { progress, recordAttempt, getSubjectStats, getOverallStats, resetProgress };
}
