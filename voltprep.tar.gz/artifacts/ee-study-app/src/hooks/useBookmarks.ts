import { useLocalStorage } from './useLocalStorage';
import { STORAGE_KEYS } from '../utils/storage';

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useLocalStorage<string[]>(STORAGE_KEYS.BOOKMARKS, []);

  const addBookmark = (id: string) => {
    setBookmarks(prev => prev.includes(id) ? prev : [...prev, id]);
  };

  const removeBookmark = (id: string) => {
    setBookmarks(prev => prev.filter(b => b !== id));
  };

  const isBookmarked = (id: string) => bookmarks.includes(id);

  const toggleBookmark = (id: string) => {
    if (isBookmarked(id)) removeBookmark(id);
    else addBookmark(id);
  };

  return { bookmarks, addBookmark, removeBookmark, isBookmarked, toggleBookmark };
}
