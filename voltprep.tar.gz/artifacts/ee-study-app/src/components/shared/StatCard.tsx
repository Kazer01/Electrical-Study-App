import { cn } from '@/lib/utils';
import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  iconColor?: string;
  iconBg?: string;
  subtitle?: string;
  className?: string;
  'data-testid'?: string;
}

export function StatCard({ label, value, icon: Icon, iconColor = 'text-primary', iconBg = 'bg-primary/10', subtitle, className, 'data-testid': testId }: StatCardProps) {
  return (
    <div
      data-testid={testId ?? `stat-card-${label.toLowerCase().replace(/\s+/g, '-')}`}
      className={cn('bg-card border border-card-border rounded-xl p-4 flex items-start gap-4', className)}
    >
      <div className={cn('p-2.5 rounded-lg flex-shrink-0', iconBg)}>
        <Icon className={cn('w-5 h-5', iconColor)} />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">{label}</p>
        <p className="text-2xl font-bold text-foreground mt-0.5 leading-none">{value}</p>
        {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
      </div>
    </div>
  );
}
