import { cn } from '@/lib/utils';
import { SUBJECTS } from '@/data/questions';
import type { SubjectId } from '@/data/questions';

interface SubjectBadgeProps {
  subject: SubjectId;
  size?: 'sm' | 'md';
  className?: string;
}

export function SubjectBadge({ subject, size = 'sm', className }: SubjectBadgeProps) {
  const info = SUBJECTS.find(s => s.id === subject);
  if (!info) return null;
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full font-medium',
        info.bgColor,
        info.color,
        size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-sm px-3 py-1',
        className
      )}
    >
      {info.name}
    </span>
  );
}
