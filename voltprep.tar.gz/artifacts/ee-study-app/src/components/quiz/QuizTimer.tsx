import { formatTime } from '@/utils/quiz';
import { Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface QuizTimerProps {
  timeRemaining: number;
  totalTime: number;
  className?: string;
}

export function QuizTimer({ timeRemaining, totalTime, className }: QuizTimerProps) {
  const pct = (timeRemaining / totalTime) * 100;
  const isUrgent = timeRemaining <= 300; // 5 minutes
  const isCritical = timeRemaining <= 60; // 1 minute

  return (
    <div
      data-testid="quiz-timer"
      className={cn(
        'flex items-center gap-2 px-3 py-2 rounded-lg border font-mono font-semibold text-base transition-colors',
        isCritical
          ? 'bg-red-500/10 border-red-500/30 text-red-500 animate-pulse'
          : isUrgent
          ? 'bg-orange-500/10 border-orange-500/30 text-orange-500'
          : 'bg-secondary border-border text-foreground',
        className
      )}
    >
      <Clock className={cn('w-4 h-4', isCritical ? 'text-red-500' : isUrgent ? 'text-orange-500' : 'text-muted-foreground')} />
      <span>{formatTime(timeRemaining)}</span>
      <div className="w-16 h-1 bg-muted rounded-full overflow-hidden">
        <div
          className={cn('h-full rounded-full transition-all', isCritical ? 'bg-red-500' : isUrgent ? 'bg-orange-500' : 'bg-primary')}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
