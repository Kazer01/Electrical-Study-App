import { cn } from '@/lib/utils';
import type { Question } from '@/data/questions';
import { Bookmark, BookmarkCheck, Flag, ChevronDown, ChevronUp, Sparkles, Loader2 } from 'lucide-react';
import { useState, useRef } from 'react';
import { SubjectBadge } from '@/components/shared/SubjectBadge';

interface QuizCardProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  selectedIndex: number | null;
  isSubmitted: boolean;
  isMarked: boolean;
  isBookmarked: boolean;
  onSelect: (index: number) => void;
  onToggleMark: () => void;
  onToggleBookmark: () => void;
}

const OPTION_LABELS = ['A', 'B', 'C', 'D'];

function getOptionStyle(
  optIdx: number,
  selectedIndex: number | null,
  correctIndex: number,
  isSubmitted: boolean
) {
  const isSelected = selectedIndex === optIdx;
  const isCorrect = correctIndex === optIdx;

  if (!isSubmitted) {
    return isSelected
      ? 'border-primary bg-primary/10 text-foreground ring-2 ring-primary/30'
      : 'border-border hover:border-primary/50 hover:bg-secondary/70 text-foreground';
  }

  if (isCorrect) return 'border-green-500 bg-green-500/10 text-green-700 dark:text-green-400';
  if (isSelected && !isCorrect) return 'border-red-500 bg-red-500/10 text-red-700 dark:text-red-400';
  return 'border-border text-muted-foreground opacity-60';
}

type AIState = 'idle' | 'loading' | 'streaming' | 'done' | 'error';

function AiExplanationPanel({ question }: { question: Question }) {
  const [aiState, setAiState] = useState<AIState>('idle');
  const [aiText, setAiText] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const abortRef = useRef<AbortController | null>(null);

  const handleAskAI = async () => {
    setAiState('loading');
    setAiText('');
    setErrorMsg('');

    abortRef.current = new AbortController();

    try {
      const res = await fetch('/api/ai/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: question.question,
          options: question.options,
          correctIndex: question.correctIndex,
          subject: question.subject,
          difficulty: question.difficulty,
          exam: question.exam,
          existingExplanation: question.explanation,
        }),
        signal: abortRef.current.signal,
      });

      if (!res.ok || !res.body) {
        setAiState('error');
        setErrorMsg('Failed to reach AI service. Check your connection.');
        return;
      }

      setAiState('streaming');
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          try {
            const parsed = JSON.parse(line.slice(6));
            if (parsed.error) {
              setAiState('error');
              setErrorMsg(parsed.error);
              return;
            }
            if (parsed.done) {
              setAiState('done');
            } else if (parsed.content) {
              setAiText(prev => prev + parsed.content);
            }
          } catch {
            /* malformed chunk — ignore */
          }
        }
      }

      setAiState('done');
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') return;
      setAiState('error');
      setErrorMsg('Something went wrong. Please try again.');
    }
  };

  const handleStop = () => {
    abortRef.current?.abort();
    setAiState('done');
  };

  return (
    <div className="mt-4 rounded-xl border border-purple-500/30 bg-purple-500/5 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2.5 px-4 py-3 border-b border-purple-500/20">
        <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex-shrink-0">
          <Sparkles className="w-3.5 h-3.5 text-white" />
        </div>
        <div className="flex-1">
          <span className="text-sm font-semibold text-purple-400">AI Explanation</span>
          <span className="ml-2 text-xs bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded font-medium">GPT-5</span>
        </div>
        {aiState === 'idle' && (
          <button
            data-testid={`btn-ai-explain-${question.id}`}
            onClick={handleAskAI}
            className="flex items-center gap-1.5 text-xs px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg font-medium hover:from-purple-500 hover:to-indigo-500 transition-all shadow-sm"
          >
            <Sparkles className="w-3 h-3" /> Ask AI
          </button>
        )}
        {aiState === 'streaming' && (
          <button
            onClick={handleStop}
            className="text-xs px-3 py-1.5 border border-purple-500/30 text-purple-400 rounded-lg hover:bg-purple-500/10 transition-colors"
          >
            Stop
          </button>
        )}
        {(aiState === 'done' || aiState === 'error') && (
          <button
            onClick={() => { setAiState('idle'); setAiText(''); setErrorMsg(''); }}
            className="text-xs px-3 py-1.5 border border-purple-500/30 text-purple-400 rounded-lg hover:bg-purple-500/10 transition-colors"
          >
            Regenerate
          </button>
        )}
      </div>

      {/* Body */}
      <div className="px-4 py-3">
        {aiState === 'idle' && (
          <div className="flex items-start gap-3">
            <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-purple-300/80 leading-relaxed">
                Get a step-by-step explanation tailored to this question — core concept, solution walkthrough, why wrong options fail, and an exam tip.
              </p>
              <p className="text-xs text-purple-400/60 mt-2 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400/60 inline-block" />
                Powered by OpenAI via Replit AI Integrations · No API key needed
              </p>
            </div>
          </div>
        )}

        {aiState === 'loading' && (
          <div className="flex items-center gap-3 py-2">
            <Loader2 className="w-4 h-4 text-purple-400 animate-spin flex-shrink-0" />
            <div className="flex-1 space-y-2">
              <div className="h-3 bg-purple-500/20 rounded w-full no-transition" style={{ animation: 'pulse 2s cubic-bezier(0.4,0,0.6,1) infinite' }} />
              <div className="h-3 bg-purple-500/20 rounded w-4/5 no-transition" style={{ animation: 'pulse 2s cubic-bezier(0.4,0,0.6,1) infinite' }} />
              <div className="h-3 bg-purple-500/20 rounded w-3/5 no-transition" style={{ animation: 'pulse 2s cubic-bezier(0.4,0,0.6,1) infinite' }} />
            </div>
          </div>
        )}

        {(aiState === 'streaming' || aiState === 'done') && aiText && (
          <div className="prose prose-sm prose-invert max-w-none">
            <MarkdownText text={aiText} />
            {aiState === 'streaming' && (
              <span className="inline-block w-2 h-4 bg-purple-400 ml-0.5 animate-pulse" />
            )}
          </div>
        )}

        {aiState === 'error' && (
          <div className="flex items-start gap-3 py-1">
            <span className="text-red-400 text-sm">{errorMsg || 'Something went wrong.'}</span>
          </div>
        )}
      </div>
    </div>
  );
}

/** Minimal markdown renderer — handles **bold**, *italic*, headings, bullets */
function MarkdownText({ text }: { text: string }) {
  const lines = text.split('\n');
  return (
    <div className="space-y-1.5 text-sm text-foreground/90 leading-relaxed">
      {lines.map((line, i) => {
        if (line.startsWith('## ')) {
          return <p key={i} className="font-bold text-purple-300 mt-3 mb-1">{line.slice(3)}</p>;
        }
        if (line.startsWith('# ')) {
          return <p key={i} className="font-bold text-purple-300 text-base mt-3 mb-1">{line.slice(2)}</p>;
        }
        if (line.startsWith('**') && line.endsWith('**')) {
          return <p key={i} className="font-semibold text-foreground mt-2">{line.slice(2, -2)}</p>;
        }
        if (line.startsWith('- ') || line.startsWith('• ')) {
          return (
            <div key={i} className="flex gap-2">
              <span className="text-purple-400 flex-shrink-0 mt-0.5">•</span>
              <span>{renderInline(line.slice(2))}</span>
            </div>
          );
        }
        if (line.match(/^\d+\. /)) {
          const num = line.match(/^(\d+)\. /)?.[1] ?? '';
          return (
            <div key={i} className="flex gap-2">
              <span className="text-purple-400 font-medium flex-shrink-0">{num}.</span>
              <span>{renderInline(line.replace(/^\d+\. /, ''))}</span>
            </div>
          );
        }
        if (line.trim() === '') return <div key={i} className="h-1" />;
        return <p key={i}>{renderInline(line)}</p>;
      })}
    </div>
  );
}

function renderInline(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={i} className="font-semibold text-foreground">{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('*') && part.endsWith('*')) {
      return <em key={i} className="italic text-purple-300">{part.slice(1, -1)}</em>;
    }
    return part;
  });
}

export function QuizCard({
  question, questionNumber, totalQuestions,
  selectedIndex, isSubmitted, isMarked, isBookmarked,
  onSelect, onToggleMark, onToggleBookmark,
}: QuizCardProps) {
  const [showExplanation, setShowExplanation] = useState(false);
  const [showAI, setShowAI] = useState(false);

  return (
    <div className="bg-card border border-card-border rounded-xl overflow-hidden">
      {/* Card header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-muted/30">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-sm text-muted-foreground font-medium">
            Question {questionNumber} of {totalQuestions}
          </span>
          <SubjectBadge subject={question.subject} />
          <span className={cn(
            'text-xs px-2 py-0.5 rounded-full font-medium capitalize',
            question.difficulty === 'easy' ? 'bg-green-500/10 text-green-600 dark:text-green-400' :
            question.difficulty === 'medium' ? 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400' :
            'bg-red-500/10 text-red-600 dark:text-red-400'
          )}>
            {question.difficulty}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleMark}
            data-testid={`btn-mark-review-${question.id}`}
            className={cn(
              'flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg border transition-colors',
              isMarked
                ? 'bg-orange-500/10 border-orange-500/30 text-orange-500'
                : 'border-border text-muted-foreground hover:bg-secondary'
            )}
          >
            <Flag className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isMarked ? 'Marked' : 'Mark'}</span>
          </button>
          <button
            onClick={onToggleBookmark}
            data-testid={`btn-bookmark-${question.id}`}
            className={cn(
              'p-1.5 rounded-lg border transition-colors',
              isBookmarked
                ? 'bg-primary/10 border-primary/30 text-primary'
                : 'border-border text-muted-foreground hover:bg-secondary'
            )}
          >
            {isBookmarked ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Question */}
      <div className="px-5 py-5">
        <p className="text-foreground text-base leading-relaxed font-medium">{question.question}</p>
      </div>

      {/* Options */}
      <div className="px-5 pb-5 space-y-2.5">
        {question.options.map((opt, idx) => (
          <button
            key={idx}
            data-testid={`option-${question.id}-${idx}`}
            onClick={() => !isSubmitted && onSelect(idx)}
            disabled={isSubmitted}
            className={cn(
              'w-full flex items-start gap-3 p-3.5 rounded-lg border text-left transition-all duration-150',
              getOptionStyle(idx, selectedIndex, question.correctIndex, isSubmitted),
              !isSubmitted && 'cursor-pointer',
              isSubmitted && 'cursor-default'
            )}
          >
            <span className={cn(
              'flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold border',
              isSubmitted && idx === question.correctIndex ? 'bg-green-500 border-green-500 text-white' :
              isSubmitted && idx === selectedIndex && idx !== question.correctIndex ? 'bg-red-500 border-red-500 text-white' :
              selectedIndex === idx ? 'bg-primary border-primary text-white' :
              'border-current'
            )}>
              {OPTION_LABELS[idx]}
            </span>
            <span className="text-sm leading-snug pt-0.5">{opt}</span>
          </button>
        ))}
      </div>

      {/* Post-submission actions */}
      {isSubmitted && (
        <div className="px-5 pb-5 space-y-3">
          {/* Standard explanation */}
          <div>
            <button
              onClick={() => setShowExplanation(s => !s)}
              data-testid={`btn-explanation-${question.id}`}
              className="flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
            >
              {showExplanation ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              {showExplanation ? 'Hide' : 'Show'} Explanation
            </button>
            {showExplanation && (
              <div className="mt-3 p-3.5 bg-blue-500/5 border border-blue-500/20 rounded-lg">
                <p className="text-sm text-foreground leading-relaxed">{question.explanation}</p>
              </div>
            )}
          </div>

          {/* AI explanation toggle */}
          <div>
            <button
              onClick={() => setShowAI(s => !s)}
              data-testid={`btn-toggle-ai-${question.id}`}
              className="flex items-center gap-2 text-sm font-medium text-purple-400 hover:text-purple-300 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              {showAI ? 'Hide' : 'Get'} AI Explanation
              <span className="text-xs bg-purple-500/15 text-purple-400 px-1.5 py-0.5 rounded">Live</span>
            </button>
            {showAI && <AiExplanationPanel question={question} />}
          </div>
        </div>
      )}
    </div>
  );
}
