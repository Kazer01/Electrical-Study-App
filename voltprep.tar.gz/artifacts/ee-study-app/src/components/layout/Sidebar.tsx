import { Link, useLocation } from 'wouter';
import { Zap, LayoutDashboard, BookOpen, FlaskConical, FileText, Bookmark, Home, X, ChevronLeft, ChevronRight, CalendarDays } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getDailyResult, getTodayKey } from '@/utils/dailyQuiz';

const NAV_ITEMS = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/daily-quiz', label: 'Daily Quiz', icon: CalendarDays, badge: 'daily' },
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/subjects', label: 'Subjects', icon: BookOpen },
  { path: '/mock-test', label: 'Mock Test', icon: FileText },
  { path: '/formulas', label: 'Formulas', icon: FlaskConical },
  { path: '/bookmarks', label: 'Bookmarks', icon: Bookmark },
];

interface SidebarProps {
  mobileOpen: boolean;
  onMobileClose: () => void;
  collapsed: boolean;
  onCollapsedToggle: () => void;
}

function DailyDot({ collapsed }: { collapsed: boolean }) {
  const done = !!getDailyResult();
  if (done) return null;
  return (
    <span className={cn(
      'flex-shrink-0 w-2 h-2 rounded-full bg-orange-400',
      collapsed ? 'absolute top-1.5 right-1.5' : ''
    )} />
  );
}

function NavItem({
  path, label, icon: Icon, badge, isActive, onClick, collapsed,
}: {
  path: string; label: string; icon: React.ComponentType<{ className?: string }>;
  badge?: string; isActive: boolean; onClick: () => void; collapsed: boolean;
}) {
  const showDailyDot = badge === 'daily';
  return (
    <li>
      <Link
        href={path}
        onClick={onClick}
        data-testid={`nav-${label.toLowerCase().replace(/\s+/g, '-')}`}
        className={cn(
          'relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group',
          collapsed && 'justify-center px-2',
          isActive
            ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-sm'
            : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
        )}
      >
        <Icon className={cn(
          'w-4 h-4 flex-shrink-0',
          isActive ? 'text-sidebar-primary-foreground' : 'text-sidebar-foreground/60 group-hover:text-sidebar-accent-foreground'
        )} />
        {!collapsed && <span className="flex-1">{label}</span>}
        {showDailyDot && <DailyDot collapsed={collapsed} />}
      </Link>
    </li>
  );
}

export function Sidebar({ mobileOpen, onMobileClose, collapsed, onCollapsedToggle }: SidebarProps) {
  const [location] = useLocation();

  const navContent = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={cn('flex items-center gap-3 px-4 py-5 border-b border-sidebar-border', collapsed && 'justify-center px-3')}>
        <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-primary/20 text-sidebar-primary flex-shrink-0">
          <Zap className="w-5 h-5" />
        </div>
        {!collapsed && (
          <div>
            <span className="font-bold text-sidebar-foreground text-lg tracking-tight">VoltPrep</span>
            <p className="text-xs text-sidebar-foreground/50 leading-none mt-0.5">EE Study Platform</p>
          </div>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-4 overflow-y-auto">
        <ul className="space-y-1 px-2">
          {NAV_ITEMS.map(({ path, label, icon, badge }) => {
            const isActive = location === path || (path !== '/' && location.startsWith(path));
            return (
              <NavItem
                key={path}
                path={path}
                label={label}
                icon={icon}
                badge={badge}
                isActive={isActive}
                onClick={onMobileClose}
                collapsed={collapsed}
              />
            );
          })}
        </ul>
      </nav>

      {/* Collapse toggle (desktop) */}
      <div className="hidden lg:flex border-t border-sidebar-border p-2">
        <button
          onClick={onCollapsedToggle}
          data-testid="btn-toggle-sidebar"
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sidebar-foreground/50 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground text-xs transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <><ChevronLeft className="w-4 h-4" /><span>Collapse</span></>}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={onMobileClose} />
      )}

      {/* Mobile drawer */}
      <aside className={cn(
        'fixed top-0 left-0 h-full bg-sidebar z-50 lg:hidden transition-transform duration-200 w-64',
        mobileOpen ? 'translate-x-0' : '-translate-x-full'
      )}>
        <div className="flex items-center justify-between px-4 py-3 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-sidebar-primary" />
            <span className="font-bold text-sidebar-foreground">VoltPrep</span>
          </div>
          <button onClick={onMobileClose} className="text-sidebar-foreground/60 hover:text-sidebar-foreground p-1 rounded" data-testid="btn-close-mobile-nav">
            <X className="w-5 h-5" />
          </button>
        </div>
        <nav className="py-4">
          <ul className="space-y-1 px-2">
            {NAV_ITEMS.map(({ path, label, icon: Icon, badge }) => {
              const isActive = location === path || (path !== '/' && location.startsWith(path));
              const showDot = badge === 'daily' && !getDailyResult();
              return (
                <li key={path}>
                  <Link href={path} onClick={onMobileClose}
                    className={cn(
                      'relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
                      isActive ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    )}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span className="flex-1">{label}</span>
                    {showDot && <span className="w-2 h-2 rounded-full bg-orange-400 flex-shrink-0" />}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </aside>

      {/* Desktop sidebar */}
      <aside className={cn(
        'hidden lg:flex flex-col h-full bg-sidebar border-r border-sidebar-border flex-shrink-0 transition-all duration-200',
        collapsed ? 'w-16' : 'w-60'
      )}>
        {navContent}
      </aside>
    </>
  );
}
