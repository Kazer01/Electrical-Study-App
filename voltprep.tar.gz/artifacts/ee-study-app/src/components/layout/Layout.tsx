import { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { STORAGE_KEYS } from '@/utils/storage';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useLocalStorage<boolean>('ee_sidebar_collapsed', false);
  const [streak] = useLocalStorage<{ lastDate: string; count: number }>(STORAGE_KEYS.STREAK, { lastDate: '', count: 0 });

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
        collapsed={collapsed}
        onCollapsedToggle={() => setCollapsed(c => !c)}
      />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header
          onMobileMenuOpen={() => setMobileOpen(true)}
          streak={streak.count}
        />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
