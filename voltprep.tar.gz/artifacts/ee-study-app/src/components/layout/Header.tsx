import { Menu, Sun, Moon, Search, Flame } from 'lucide-react';
import { useState } from 'react';
import { useTheme } from '@/hooks/useTheme';
import { useLocation } from 'wouter';
import { QUESTIONS } from '@/data/questions';
import { FORMULAS } from '@/data/formulas';
import { cn } from '@/lib/utils';

const PAGE_TITLES: Record<string, string> = {
  '/': 'Home',
  '/dashboard': 'Dashboard',
  '/subjects': 'Subjects',
  '/mock-test': 'Mock Test',
  '/formulas': 'Formula Revision',
  '/bookmarks': 'Bookmarks',
};

interface HeaderProps {
  onMobileMenuOpen: () => void;
  streak: number;
}

interface SearchResult {
  type: 'question' | 'formula';
  id: string;
  title: string;
  subject: string;
}

export function Header({ onMobileMenuOpen, streak }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [showResults, setShowResults] = useState(false);

  const pageTitle = Object.entries(PAGE_TITLES).find(([path]) =>
    path === '/' ? location === '/' : location.startsWith(path)
  )?.[1] ?? 'VoltPrep';

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    if (q.trim().length < 2) { setSearchResults([]); setShowResults(false); return; }
    const lower = q.toLowerCase();
    const qResults: SearchResult[] = QUESTIONS
      .filter(question => question.question.toLowerCase().includes(lower) || question.tags.some(t => t.includes(lower)))
      .slice(0, 4)
      .map(question => ({ type: 'question' as const, id: question.id, title: question.question.slice(0, 70) + '…', subject: question.subject.replace(/-/g, ' ') }));
    const fResults: SearchResult[] = FORMULAS
      .filter(f => f.title.toLowerCase().includes(lower) || f.formula.toLowerCase().includes(lower))
      .slice(0, 3)
      .map(f => ({ type: 'formula' as const, id: f.id, title: f.title, subject: f.subject.replace(/-/g, ' ') }));
    setSearchResults([...qResults, ...fResults]);
    setShowResults(true);
  };

  return (
    <header className="h-14 flex items-center gap-3 px-4 border-b border-border bg-card/80 backdrop-blur-sm flex-shrink-0">
      {/* Mobile menu button */}
      <button
        onClick={onMobileMenuOpen}
        data-testid="btn-mobile-menu"
        className="lg:hidden p-2 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Page title */}
      <h1 className="font-semibold text-foreground text-base hidden sm:block">{pageTitle}</h1>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Search */}
      <div className="relative hidden md:block">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="search"
            placeholder="Search questions & formulas..."
            value={searchQuery}
            onChange={e => handleSearch(e.target.value)}
            onBlur={() => setTimeout(() => setShowResults(false), 200)}
            onFocus={() => searchResults.length > 0 && setShowResults(true)}
            data-testid="input-global-search"
            className="w-64 pl-9 pr-3 py-1.5 text-sm bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors placeholder:text-muted-foreground text-foreground"
          />
        </div>
        {showResults && searchResults.length > 0 && (
          <div className="absolute top-full mt-1 w-96 right-0 bg-card border border-border rounded-xl shadow-xl z-50 overflow-hidden">
            {searchResults.map(r => (
              <div key={r.id} className={cn('px-3 py-2.5 hover:bg-secondary cursor-pointer transition-colors border-b border-border last:border-0')}>
                <div className="flex items-start gap-2">
                  <span className={cn('text-xs px-1.5 py-0.5 rounded font-medium flex-shrink-0 mt-0.5', r.type === 'question' ? 'bg-primary/10 text-primary' : 'bg-accent/10 text-accent')}>
                    {r.type === 'question' ? 'Q' : 'F'}
                  </span>
                  <div>
                    <p className="text-sm text-foreground leading-snug">{r.title}</p>
                    <p className="text-xs text-muted-foreground capitalize mt-0.5">{r.subject}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Streak */}
      {streak > 0 && (
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-orange-500/10 rounded-lg" data-testid="streak-badge">
          <Flame className="w-4 h-4 text-orange-500" />
          <span className="text-sm font-semibold text-orange-500">{streak}</span>
        </div>
      )}

      {/* Theme toggle */}
      <button
        onClick={toggleTheme}
        data-testid="btn-toggle-theme"
        className="p-2 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
        aria-label="Toggle theme"
      >
        {theme === 'dark' ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
      </button>
    </header>
  );
}
