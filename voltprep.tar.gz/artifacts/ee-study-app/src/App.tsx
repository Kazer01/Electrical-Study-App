import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout/Layout";
import { useTheme } from "@/hooks/useTheme";
import HomePage from "@/pages/HomePage";
import DashboardPage from "@/pages/DashboardPage";
import SubjectsPage from "@/pages/SubjectsPage";
import QuizPage from "@/pages/QuizPage";
import MockTestPage from "@/pages/MockTestPage";
import ResultPage from "@/pages/ResultPage";
import FormulasPage from "@/pages/FormulasPage";
import BookmarksPage from "@/pages/BookmarksPage";
import DailyQuizPage from "@/pages/DailyQuizPage";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function ThemeInit() {
  useTheme();
  return null;
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/dashboard" component={DashboardPage} />
        <Route path="/subjects" component={SubjectsPage} />
        <Route path="/quiz/:subjectId" component={QuizPage} />
        <Route path="/mock-test" component={MockTestPage} />
        <Route path="/result/:attemptId" component={ResultPage} />
        <Route path="/formulas" component={FormulasPage} />
        <Route path="/bookmarks" component={BookmarksPage} />
        <Route path="/daily-quiz" component={DailyQuizPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <ThemeInit />
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
