import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Trophy, BookOpen, Clock, Target, TrendingUp, BarChart3 } from 'lucide-react';
import { StatCard } from '@/components/shared/StatCard';
import { useProgress } from '@/hooks/useProgress';
import { getAttempts } from '@/utils/storage';
import { SUBJECTS, QUESTIONS } from '@/data/questions';
import { formatTime } from '@/utils/quiz';
import { cn } from '@/lib/utils';

const CHART_COLORS = ['#3b82f6', '#06b6d4', '#22c55e', '#a855f7', '#f97316', '#ec4899', '#eab308', '#6366f1'];

export default function DashboardPage() {
  const { getOverallStats, getSubjectStats } = useProgress();
  const stats = getOverallStats();
  const attempts = getAttempts();

  const recentAccuracy = attempts.slice(0, 7).reverse().map((a, i) => ({
    name: `#${i + 1}`,
    accuracy: a.totalQuestions > 0 ? Math.round((a.correct / a.totalQuestions) * 100) : 0,
    score: `${a.correct}/${a.totalQuestions}`,
  }));

  const subjectData = SUBJECTS.map((s, i) => {
    const prog = getSubjectStats(s.id);
    const total = QUESTIONS.filter(q => q.subject === s.id).length;
    return {
      name: s.name.split(' ')[0],
      fullName: s.name,
      attempted: prog.attempted,
      correct: prog.correct,
      accuracy: prog.attempted > 0 ? Math.round((prog.correct / prog.attempted) * 100) : 0,
      remaining: Math.max(0, total - prog.attempted),
      color: CHART_COLORS[i % CHART_COLORS.length],
    };
  });

  const pieData = subjectData.filter(s => s.correct > 0).map(s => ({ name: s.name, value: s.correct }));

  const studyTimeH = Math.floor(stats.totalTime / 3600);
  const studyTimeM = Math.floor((stats.totalTime % 3600) / 60);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-foreground">Dashboard</h2>
        <p className="text-muted-foreground text-sm">Your study analytics and progress overview</p>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard label="Total Attempted" value={stats.totalAttempted} icon={BookOpen} iconColor="text-primary" iconBg="bg-primary/10" />
        <StatCard label="Correct Answers" value={stats.totalCorrect} icon={Trophy} iconColor="text-yellow-500" iconBg="bg-yellow-500/10" />
        <StatCard label="Overall Accuracy" value={`${stats.accuracy}%`} icon={Target} iconColor="text-green-500" iconBg="bg-green-500/10" />
        <StatCard label="Study Time" value={`${studyTimeH}h ${studyTimeM}m`} icon={Clock} iconColor="text-purple-500" iconBg="bg-purple-500/10" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Accuracy trend */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Accuracy Trend (Last 7 Attempts)</h3>
          </div>
          {recentAccuracy.length === 0 ? (
            <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No attempts yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={recentAccuracy}>
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'hsl(220 15% 55%)' }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: 'hsl(220 15% 55%)' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: 'hsl(220 28% 12%)', border: '1px solid hsl(220 25% 20%)', borderRadius: '8px', fontSize: '12px' }}
                  labelStyle={{ color: 'hsl(220 15% 90%)' }}
                  itemStyle={{ color: '#3b82f6' }}
                  formatter={(v: number) => [`${v}%`, 'Accuracy']}
                />
                <Line type="monotone" dataKey="accuracy" stroke="#3b82f6" strokeWidth={2} dot={{ fill: '#3b82f6', r: 3 }} activeDot={{ r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Subject accuracy bar chart */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-4 h-4 text-accent" />
            <h3 className="font-semibold text-foreground">Questions Attempted per Subject</h3>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={subjectData} barSize={18}>
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'hsl(220 15% 55%)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: 'hsl(220 15% 55%)' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: 'hsl(220 28% 12%)', border: '1px solid hsl(220 25% 20%)', borderRadius: '8px', fontSize: '12px' }}
                labelStyle={{ color: 'hsl(220 15% 90%)' }}
                formatter={(v: number, _name: string, props: { payload?: { fullName?: string } }) => [v, props?.payload?.fullName ?? '']}
              />
              <Bar dataKey="attempted" radius={[4, 4, 0, 0]}>
                {subjectData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Correct answers pie */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4">Correct Answers by Subject</h3>
          {pieData.length === 0 ? (
            <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No data yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" outerRadius={65} dataKey="value" label={({ name, percent }) => `${name} ${Math.round((percent as number) * 100)}%`} labelLine={false} fontSize={10}>
                  {pieData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: 'hsl(220 28% 12%)', border: '1px solid hsl(220 25% 20%)', borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Subject breakdown table */}
        <div className="lg:col-span-2 bg-card border border-card-border rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4">Subject-wise Breakdown</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground text-xs border-b border-border">
                  <th className="pb-2 font-medium">Subject</th>
                  <th className="pb-2 font-medium text-right">Attempted</th>
                  <th className="pb-2 font-medium text-right">Correct</th>
                  <th className="pb-2 font-medium text-right">Accuracy</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {subjectData.map(s => (
                  <tr key={s.name} data-testid={`dashboard-subject-${s.name}`}>
                    <td className="py-2.5 font-medium text-foreground">{s.fullName}</td>
                    <td className="py-2.5 text-right text-muted-foreground">{s.attempted}</td>
                    <td className="py-2.5 text-right text-muted-foreground">{s.correct}</td>
                    <td className="py-2.5 text-right">
                      <span className={cn('font-semibold', s.accuracy >= 70 ? 'text-green-500' : s.accuracy >= 50 ? 'text-yellow-500' : s.attempted > 0 ? 'text-red-500' : 'text-muted-foreground')}>
                        {s.attempted > 0 ? `${s.accuracy}%` : '—'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Recent attempts */}
      <div className="bg-card border border-card-border rounded-xl p-5">
        <h3 className="font-semibold text-foreground mb-4">Recent Attempts</h3>
        {attempts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">No attempts recorded yet. Start a quiz!</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground text-xs border-b border-border">
                  <th className="pb-2 font-medium">Date</th>
                  <th className="pb-2 font-medium">Subject</th>
                  <th className="pb-2 font-medium text-right">Score</th>
                  <th className="pb-2 font-medium text-right">Accuracy</th>
                  <th className="pb-2 font-medium text-right">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {attempts.slice(0, 10).map(a => {
                  const acc = a.totalQuestions > 0 ? Math.round((a.correct / a.totalQuestions) * 100) : 0;
                  return (
                    <tr key={a.id} data-testid={`attempt-row-${a.id}`}>
                      <td className="py-2.5 text-muted-foreground">{new Date(a.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</td>
                      <td className="py-2.5 font-medium text-foreground capitalize">{a.subject === 'mock' ? 'Mock Test' : a.subject.replace(/-/g, ' ')}</td>
                      <td className="py-2.5 text-right text-muted-foreground">{a.correct}/{a.totalQuestions}</td>
                      <td className="py-2.5 text-right">
                        <span className={cn('font-semibold', acc >= 70 ? 'text-green-500' : acc >= 50 ? 'text-yellow-500' : 'text-red-500')}>{acc}%</span>
                      </td>
                      <td className="py-2.5 text-right text-muted-foreground">{formatTime(a.timeTaken)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
