import { useState, useCallback } from 'react';
import { useLocation } from 'wouter';
import { ChevronLeft, ChevronRight, Send, AlertTriangle } from 'lucide-react';
import { QuizCard } from '@/components/quiz/QuizCard';
import { QuizTimer } from '@/components/quiz/QuizTimer';
import { useQuiz } from '@/hooks/useQuiz';
import { useBookmarks } from '@/hooks/useBookmarks';
import { useProgress } from '@/hooks/useProgress';
import { QUESTIONS, SUBJECTS } from '@/data/questions';
import type { SubjectId } from '@/data/questions';
import { filterQuestions, generateAttemptId, calculateScore } from '@/utils/quiz';
import { saveAttempt, updateStreak } from '@/utils/storage';
import { cn } from '@/lib/utils';

const MOCK_DURATION = 90 * 60; // 90 minutes
const MOCK_COUNT = 30;

function getMockQuestions() {
  const perSubject = Math.ceil(MOCK_COUNT / SUBJECTS.length);
  const qs: typeof QUESTIONS = [];
  for (const s of SUBJECTS) {
    const subQ = filterQuestions(QUESTIONS, { subjects: [s.id], count: perSubject });
    qs.push(...subQ);
  }
  return filterQuestions(qs, { count: MOCK_COUNT });
}

export default function MockTestPage() {
  const [, setLocation] = useLocation();
  const [started, setStarted] = useState(false);
  const [questions] = useState(() => getMockQuestions());
  const [showConfirm, setShowConfirm] = useState(false);
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const { recordAttempt } = useProgress();

  const handleTimeUp = useCallback(() => {
    doSubmit();
  }, []);

  const quiz = useQuiz({ questions, timeLimitSeconds: MOCK_DURATION, onTimeUp: handleTimeUp });

  const doSubmit = useCallback(() => {
    quiz.submitQuiz();
    const scoreData = calculateScore(questions, quiz.answers);
    const timeTaken = quiz.getTimeTaken();
    const id = generateAttemptId();
    const attempt = {
      id, date: new Date().toISOString(), subject: 'mock' as const,
      totalQuestions: questions.length, correct: scoreData.correct, timeTaken,
      answers: questions.map(q => ({
        questionId: q.id,
        selectedIndex: quiz.answers[q.id] ?? -1,
        isCorrect: quiz.answers[q.id] === q.correctIndex,
      })),
    };
    saveAttempt(attempt);
    updateStreak();
    // Record per-subject progress
    const subjectGroups: Partial<Record<SubjectId, { correct: number; total: number }>> = {};
    for (const q of questions) {
      if (!subjectGroups[q.subject]) subjectGroups[q.subject] = { correct: 0, total: 0 };
      subjectGroups[q.subject]!.total++;
      if (quiz.answers[q.id] === q.correctIndex) subjectGroups[q.subject]!.correct++;
    }
    for (const [subj, data] of Object.entries(subjectGroups)) {
      if (data) recordAttempt(subj as SubjectId, data.correct, data.total, 0);
    }
    setShowConfirm(false);
    setTimeout(() => setLocation(`/result/${id}`), 300);
  }, [quiz, questions, recordAttempt, setLocation]);

  if (!started) {
    return (
      <div className="max-w-xl mx-auto">
        <div className="bg-card border border-card-border rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Send className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-2xl font-bold text-foreground">Full Mock Test</h2>
          <p className="text-muted-foreground mt-2 text-sm">Simulate real exam conditions with randomized questions from all subjects.</p>
          <div className="grid grid-cols-3 gap-4 my-6">
            {[['30', 'Questions'], ['90', 'Minutes'], ['8', 'Subjects']].map(([val, lbl]) => (
              <div key={lbl} className="bg-secondary rounded-xl p-3">
                <div className="text-2xl font-bold text-primary">{val}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{lbl}</div>
              </div>
            ))}
          </div>
          <div className="text-left bg-secondary/50 border border-border rounded-lg p-4 mb-6 space-y-2">
            <p className="text-sm font-medium text-foreground">Instructions:</p>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Questions from all 8 EE subjects</li>
              <li>• Timer auto-submits when 90 minutes expire</li>
              <li>• Mark questions for review using the flag icon</li>
              <li>• Explanations revealed after submission</li>
              <li>• Results saved to your progress history</li>
            </ul>
          </div>
          <button
            data-testid="btn-start-mock-test"
            onClick={() => { setStarted(true); quiz.startQuiz(); }}
            className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:bg-primary/90 transition-colors"
          >
            Start Mock Test
          </button>
        </div>
      </div>
    );
  }

  const current = quiz.currentQuestion;
  if (!current) return null;
  const answered = Object.values(quiz.answers).filter(a => a !== null && a !== undefined).length;
  const unanswered = questions.length - answered;

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Confirm dialog */}
      {showConfirm && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-card-border rounded-2xl p-6 max-w-sm w-full">
            <div className="flex items-center gap-3 mb-3">
              <AlertTriangle className="w-5 h-5 text-yellow-500 flex-shrink-0" />
              <h3 className="font-bold text-foreground">Submit Mock Test?</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-1">You have answered <strong className="text-foreground">{answered}</strong> of {questions.length} questions.</p>
            {unanswered > 0 && <p className="text-sm text-yellow-500 mb-4">{unanswered} question{unanswered > 1 ? 's' : ''} unanswered.</p>}
            <div className="flex gap-3">
              <button onClick={() => setShowConfirm(false)} data-testid="btn-cancel-submit" className="flex-1 py-2 bg-secondary border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary/80 transition-colors">Cancel</button>
              <button onClick={doSubmit} data-testid="btn-confirm-submit" className="flex-1 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors">Submit</button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-bold text-foreground">Mock Test</h2>
          <p className="text-xs text-muted-foreground">{answered}/{questions.length} answered</p>
        </div>
        <QuizTimer timeRemaining={quiz.timeRemaining} totalTime={MOCK_DURATION} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Navigator */}
        <div className="lg:col-span-1">
          <div className="bg-card border border-card-border rounded-xl p-4">
            <p className="text-xs font-medium text-muted-foreground mb-3">Questions</p>
            <div className="grid grid-cols-5 lg:grid-cols-5 gap-1">
              {questions.map((q, i) => {
                const isAnswered = quiz.answers[q.id] !== undefined && quiz.answers[q.id] !== null;
                const isMarked = quiz.markedForReview.includes(q.id);
                const isCurrent = quiz.currentIndex === i;
                return (
                  <button
                    key={q.id}
                    data-testid={`mock-nav-${i}`}
                    onClick={() => quiz.navigateTo(i)}
                    className={cn(
                      'w-7 h-7 rounded text-xs font-semibold transition-colors',
                      isCurrent ? 'ring-2 ring-primary ring-offset-1 ring-offset-card' : '',
                      isMarked ? 'bg-orange-500/20 text-orange-500 border border-orange-500/30' :
                      isAnswered ? 'bg-green-500/20 text-green-600 border border-green-500/30' :
                      'bg-secondary text-muted-foreground border border-border hover:border-primary/50'
                    )}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
            <div className="mt-3 space-y-1 text-xs text-muted-foreground">
              <div className="flex items-center gap-2"><span className="w-3 h-3 rounded bg-green-500/20 border border-green-500/30 inline-block" />Answered</div>
              <div className="flex items-center gap-2"><span className="w-3 h-3 rounded bg-orange-500/20 border border-orange-500/30 inline-block" />Marked</div>
            </div>
            {!quiz.isSubmitted && (
              <button
                data-testid="btn-submit-mock"
                onClick={() => setShowConfirm(true)}
                className="mt-4 w-full flex items-center justify-center gap-2 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors"
              >
                <Send className="w-4 h-4" /> Submit Test
              </button>
            )}
          </div>
        </div>

        {/* Card */}
        <div className="lg:col-span-3">
          <QuizCard
            question={current}
            questionNumber={quiz.currentIndex + 1}
            totalQuestions={questions.length}
            selectedIndex={quiz.answers[current.id] ?? null}
            isSubmitted={quiz.isSubmitted}
            isMarked={quiz.markedForReview.includes(current.id)}
            isBookmarked={isBookmarked(current.id)}
            onSelect={idx => quiz.selectAnswer(current.id, idx)}
            onToggleMark={() => quiz.toggleMarkForReview(current.id)}
            onToggleBookmark={() => toggleBookmark(current.id)}
          />
          <div className="flex items-center justify-between mt-3">
            <button onClick={quiz.prevQuestion} disabled={quiz.currentIndex === 0} data-testid="btn-mock-prev"
              className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
              <ChevronLeft className="w-4 h-4" /> Prev
            </button>
            <span className="text-sm text-muted-foreground">{quiz.currentIndex + 1} / {questions.length}</span>
            <button onClick={quiz.nextQuestion} disabled={quiz.currentIndex === questions.length - 1} data-testid="btn-mock-next"
              className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
              Next <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
