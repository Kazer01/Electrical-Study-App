import { useState } from 'react';
import { Link } from 'wouter';
import { Bookmark, X, ChevronDown, ChevronUp, Play, BookOpen } from 'lucide-react';
import { QUESTIONS } from '@/data/questions';
import { FORMULAS } from '@/data/formulas';
import { useBookmarks } from '@/hooks/useBookmarks';
import { SubjectBadge } from '@/components/shared/SubjectBadge';
import { cn } from '@/lib/utils';

export default function BookmarksPage() {
  const { bookmarks, removeBookmark, isBookmarked, toggleBookmark } = useBookmarks();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'questions' | 'formulas'>('questions');

  const bookmarkedQuestions = QUESTIONS.filter(q => bookmarks.includes(q.id));
  const bookmarkedFormulas = FORMULAS.filter(f => bookmarks.includes(f.id));

  if (bookmarks.length === 0) {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="text-center py-20">
          <Bookmark className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-foreground mb-2">No bookmarks yet</h2>
          <p className="text-muted-foreground text-sm mb-6">Bookmark questions and formulas during practice to review them here.</p>
          <Link href="/subjects">
            <button data-testid="btn-go-practice" className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors mx-auto">
              <BookOpen className="w-4 h-4" /> Start Practicing
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Bookmarks</h2>
          <p className="text-muted-foreground text-sm">{bookmarkedQuestions.length} questions, {bookmarkedFormulas.length} formulas saved</p>
        </div>
        {bookmarkedQuestions.length > 0 && (
          <Link href={`/quiz/network-theory?bookmarks=true`}>
            <button data-testid="btn-quiz-bookmarks" className="flex items-center gap-2 px-3 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
              <Play className="w-4 h-4" /> Quiz Bookmarks
            </button>
          </Link>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-secondary rounded-lg p-1 w-fit">
        {(['questions', 'formulas'] as const).map(tab => (
          <button
            key={tab}
            data-testid={`tab-bookmarks-${tab}`}
            onClick={() => setActiveTab(tab)}
            className={cn('px-4 py-1.5 rounded-md text-sm font-medium capitalize transition-colors', activeTab === tab ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')}
          >
            {tab} ({tab === 'questions' ? bookmarkedQuestions.length : bookmarkedFormulas.length})
          </button>
        ))}
      </div>

      {/* Questions tab */}
      {activeTab === 'questions' && (
        <div className="space-y-3">
          {bookmarkedQuestions.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm">No bookmarked questions</div>
          ) : bookmarkedQuestions.map(q => {
            const isExpanded = expandedId === q.id;
            return (
              <div key={q.id} data-testid={`bookmark-question-${q.id}`} className="bg-card border border-card-border rounded-xl overflow-hidden">
                <div className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <SubjectBadge subject={q.subject} size="sm" />
                        <span className={cn('text-xs capitalize px-1.5 py-0.5 rounded', q.difficulty === 'easy' ? 'bg-green-500/10 text-green-600 dark:text-green-400' : q.difficulty === 'medium' ? 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400' : 'bg-red-500/10 text-red-600 dark:text-red-400')}>
                          {q.difficulty}
                        </span>
                      </div>
                      <p className="text-sm text-foreground leading-snug font-medium">{q.question}</p>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button
                        onClick={() => toggleBookmark(q.id)}
                        data-testid={`btn-remove-bookmark-${q.id}`}
                        className="p-1.5 rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors"
                        title="Remove bookmark"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={() => setExpandedId(isExpanded ? null : q.id)}
                    data-testid={`btn-expand-bookmark-${q.id}`}
                    className="mt-2 flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 transition-colors"
                  >
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    {isExpanded ? 'Hide' : 'Show'} options
                  </button>
                </div>

                {isExpanded && (
                  <div className="border-t border-border px-4 pb-4 pt-3 space-y-2">
                    {q.options.map((opt, i) => (
                      <div key={i} className={cn('flex items-start gap-2.5 p-2.5 rounded-lg text-sm', i === q.correctIndex ? 'bg-green-500/10 border border-green-500/30' : 'bg-secondary/50')}>
                        <span className={cn('font-bold flex-shrink-0 w-4', i === q.correctIndex ? 'text-green-500' : 'text-muted-foreground')}>
                          {['A','B','C','D'][i]}
                        </span>
                        <span className={i === q.correctIndex ? 'text-green-700 dark:text-green-400' : 'text-foreground'}>{opt}</span>
                      </div>
                    ))}
                    <div className="mt-3 p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg">
                      <p className="text-xs font-medium text-blue-500 mb-1">Explanation</p>
                      <p className="text-xs text-foreground leading-relaxed">{q.explanation}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Formulas tab */}
      {activeTab === 'formulas' && (
        <div className="space-y-3">
          {bookmarkedFormulas.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm">No bookmarked formulas</div>
          ) : bookmarkedFormulas.map(f => {
            const isExpanded = expandedId === f.id;
            return (
              <div key={f.id} data-testid={`bookmark-formula-${f.id}`} className="bg-card border border-card-border rounded-xl overflow-hidden">
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-foreground">{f.title}</h3>
                        <SubjectBadge subject={f.subject} size="sm" />
                      </div>
                      <div className="bg-muted border border-border rounded-lg px-3 py-2 font-mono font-bold text-primary text-base">
                        {f.formula}
                      </div>
                    </div>
                    <button
                      onClick={() => removeBookmark(f.id)}
                      data-testid={`btn-remove-bookmark-formula-${f.id}`}
                      className="p-1.5 rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors flex-shrink-0"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => setExpandedId(isExpanded ? null : f.id)}
                    data-testid={`btn-expand-formula-bookmark-${f.id}`}
                    className="mt-3 flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 transition-colors"
                  >
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    {isExpanded ? 'Collapse' : 'Show details'}
                  </button>
                </div>

                {isExpanded && (
                  <div className="border-t border-border px-4 pb-4 pt-3">
                    <p className="text-sm text-muted-foreground mb-3">{f.description}</p>
                    {f.variables.length > 0 && (
                      <table className="w-full text-sm mb-3">
                        <thead><tr className="border-b border-border"><th className="text-left pb-1 text-xs text-muted-foreground w-20">Symbol</th><th className="text-left pb-1 text-xs text-muted-foreground">Meaning</th></tr></thead>
                        <tbody className="divide-y divide-border">{f.variables.map((v, i) => <tr key={i}><td className="py-1 font-mono font-semibold text-accent text-xs">{v.symbol}</td><td className="py-1 text-muted-foreground text-xs">{v.meaning}</td></tr>)}</tbody>
                      </table>
                    )}
                    <div className="p-3 bg-accent/5 border border-accent/20 rounded-lg">
                      <p className="text-xs font-medium text-accent mb-1">Example</p>
                      <p className="text-xs text-foreground">{f.example}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
