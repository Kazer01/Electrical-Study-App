import { Link } from 'wouter';
import { Network, Cog, Zap, Sliders, Cpu, Gauge, RadioTower, Binary, ArrowRight, BookOpen } from 'lucide-react';
import { ProgressBar } from '@/components/quiz/ProgressBar';
import { useProgress } from '@/hooks/useProgress';
import { SUBJECTS, QUESTIONS } from '@/data/questions';
import { cn } from '@/lib/utils';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Network, Cog, Zap, Sliders, Cpu, Gauge, RadioTower, Binary,
};

const EXAM_FILTERS = ['All', 'GATE', 'SSC-JE', 'ESE', 'Diploma', 'B.Tech'] as const;

import { useState } from 'react';
import type { ExamType } from '@/data/questions';

export default function SubjectsPage() {
  const { getSubjectStats } = useProgress();
  const [examFilter, setExamFilter] = useState<'All' | ExamType>('All');

  const filteredSubjects = SUBJECTS.map(subject => {
    const allQ = QUESTIONS.filter(q => q.subject === subject.id);
    const filteredQ = examFilter === 'All' ? allQ : allQ.filter(q => q.exam.includes(examFilter as ExamType));
    return { ...subject, totalQ: filteredQ.length, allTotal: allQ.length };
  }).filter(s => s.totalQ > 0);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Subjects</h2>
          <p className="text-muted-foreground text-sm">{QUESTIONS.length} questions across {SUBJECTS.length} subjects</p>
        </div>
      </div>

      {/* Exam filter */}
      <div className="flex flex-wrap gap-2">
        {EXAM_FILTERS.map(f => (
          <button
            key={f}
            data-testid={`filter-exam-${f}`}
            onClick={() => setExamFilter(f)}
            className={cn(
              'px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors',
              examFilter === f
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-card border-border text-muted-foreground hover:border-primary/50 hover:text-foreground'
            )}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Subject grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
        {filteredSubjects.map(subject => {
          const Icon = ICON_MAP[subject.iconName] ?? BookOpen;
          const s = getSubjectStats(subject.id);
          const acc = s.attempted > 0 ? Math.round((s.correct / s.attempted) * 100) : 0;
          const pct = subject.allTotal > 0 ? (s.attempted / subject.allTotal) * 100 : 0;

          return (
            <div
              key={subject.id}
              data-testid={`subject-card-${subject.id}`}
              className="bg-card border border-card-border rounded-xl p-5 hover:border-primary/30 transition-all group"
            >
              <div className="flex items-start gap-4">
                <div className={cn('p-3 rounded-xl flex-shrink-0', subject.bgColor)}>
                  <Icon className={cn('w-6 h-6', subject.color)} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground">{subject.name}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{subject.description}</p>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{s.attempted} / {subject.allTotal} attempted</span>
                  {s.attempted > 0 && (
                    <span className={cn('font-medium', acc >= 70 ? 'text-green-500' : acc >= 50 ? 'text-yellow-500' : 'text-red-500')}>
                      {acc}% accuracy
                    </span>
                  )}
                </div>
                <ProgressBar value={pct} max={100} height="h-1.5" color={pct >= 70 ? 'bg-green-500' : pct >= 40 ? 'bg-primary' : 'bg-muted-foreground'} />
              </div>

              <div className="mt-4 flex gap-2">
                <Link href={`/quiz/${subject.id}?count=10`} className="flex-1">
                  <button
                    data-testid={`btn-practice-${subject.id}`}
                    className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-primary/10 text-primary border border-primary/20 rounded-lg text-sm font-medium hover:bg-primary/20 transition-colors"
                  >
                    Practice <ArrowRight className="w-4 h-4" />
                  </button>
                </Link>
                <Link href={`/quiz/${subject.id}?count=5`}>
                  <button
                    data-testid={`btn-quick-quiz-${subject.id}`}
                    className="flex items-center justify-center gap-2 px-3 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors"
                  >
                    Quick (5Q)
                  </button>
                </Link>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
