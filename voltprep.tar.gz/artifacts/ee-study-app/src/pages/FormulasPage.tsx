import { useState } from 'react';
import { Search, ChevronDown, ChevronUp, Bookmark, BookmarkCheck } from 'lucide-react';
import { FORMULAS } from '@/data/formulas';
import { SUBJECTS } from '@/data/questions';
import type { SubjectId } from '@/data/questions';
import { useBookmarks } from '@/hooks/useBookmarks';
import { SubjectBadge } from '@/components/shared/SubjectBadge';
import { cn } from '@/lib/utils';

export default function FormulasPage() {
  const [search, setSearch] = useState('');
  const [activeSubject, setActiveSubject] = useState<SubjectId | 'all'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const { isBookmarked, toggleBookmark } = useBookmarks();

  const filtered = FORMULAS.filter(f => {
    const matchSubject = activeSubject === 'all' || f.subject === activeSubject;
    const q = search.toLowerCase();
    const matchSearch = !q || f.title.toLowerCase().includes(q) || f.formula.toLowerCase().includes(q) || f.description.toLowerCase().includes(q);
    return matchSubject && matchSearch;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <div>
        <h2 className="text-xl font-bold text-foreground">Formula Revision</h2>
        <p className="text-muted-foreground text-sm">{FORMULAS.length} formulas across all subjects</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="search"
          placeholder="Search formulas..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          data-testid="input-formula-search"
          className="w-full pl-9 pr-4 py-2.5 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors text-foreground placeholder:text-muted-foreground"
        />
      </div>

      {/* Subject tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        <button
          data-testid="filter-formula-all"
          onClick={() => setActiveSubject('all')}
          className={cn('flex-shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors', activeSubject === 'all' ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-muted-foreground hover:text-foreground hover:border-primary/40')}
        >
          All Subjects
        </button>
        {SUBJECTS.map(s => (
          <button
            key={s.id}
            data-testid={`filter-formula-${s.id}`}
            onClick={() => setActiveSubject(s.id)}
            className={cn('flex-shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors', activeSubject === s.id ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-muted-foreground hover:text-foreground hover:border-primary/40')}
          >
            {s.name.split(' ')[0]}
          </button>
        ))}
      </div>

      {/* Formulas */}
      <div className="space-y-3">
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Search className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No formulas match your search</p>
          </div>
        )}
        {filtered.map(formula => {
          const isExpanded = expandedId === formula.id;
          const bookmarked = isBookmarked(formula.id);
          return (
            <div
              key={formula.id}
              data-testid={`formula-card-${formula.id}`}
              className="bg-card border border-card-border rounded-xl overflow-hidden"
            >
              <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <h3 className="font-semibold text-foreground">{formula.title}</h3>
                      <SubjectBadge subject={formula.subject} size="sm" />
                    </div>
                    <div className="bg-muted border border-border rounded-lg px-4 py-3 font-mono text-lg font-bold text-primary tracking-wide">
                      {formula.formula}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{formula.description}</p>
                  </div>
                  <button
                    onClick={() => toggleBookmark(formula.id)}
                    data-testid={`btn-bookmark-formula-${formula.id}`}
                    className={cn('p-2 rounded-lg border transition-colors flex-shrink-0', bookmarked ? 'bg-primary/10 border-primary/30 text-primary' : 'border-border text-muted-foreground hover:bg-secondary')}
                  >
                    {bookmarked ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                  </button>
                </div>

                {/* Variables table */}
                {formula.variables.length > 0 && (
                  <div className="mt-3 overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-left border-b border-border">
                          <th className="pb-1.5 text-xs font-medium text-muted-foreground w-20">Symbol</th>
                          <th className="pb-1.5 text-xs font-medium text-muted-foreground">Meaning</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {formula.variables.map((v, i) => (
                          <tr key={i}>
                            <td className="py-1.5 font-mono font-semibold text-accent text-xs">{v.symbol}</td>
                            <td className="py-1.5 text-muted-foreground text-xs">{v.meaning}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Expand example */}
                <button
                  onClick={() => setExpandedId(isExpanded ? null : formula.id)}
                  data-testid={`btn-expand-example-${formula.id}`}
                  className="mt-3 flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 transition-colors"
                >
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  {isExpanded ? 'Hide' : 'Show'} worked example
                </button>
              </div>

              {isExpanded && (
                <div className="border-t border-border bg-accent/5 px-4 py-3">
                  <p className="text-xs font-semibold text-accent uppercase tracking-wide mb-1">Worked Example</p>
                  <p className="text-sm text-foreground leading-relaxed">{formula.example}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
