import { Link } from 'wouter';
import { Zap, BookOpen, Trophy, Bookmark, Clock, ArrowRight, BarChart3, Target, Flame } from 'lucide-react';
import { StatCard } from '@/components/shared/StatCard';
import { ProgressBar } from '@/components/quiz/ProgressBar';
import { useProgress } from '@/hooks/useProgress';
import { useBookmarks } from '@/hooks/useBookmarks';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { STORAGE_KEYS, getAttempts } from '@/utils/storage';
import { SUBJECTS, QUESTIONS } from '@/data/questions';
import { formatTime } from '@/utils/quiz';
import { cn } from '@/lib/utils';

export default function HomePage() {
  const { getOverallStats, getSubjectStats } = useProgress();
  const { bookmarks } = useBookmarks();
  const [streak] = useLocalStorage(STORAGE_KEYS.STREAK, { lastDate: '', count: 0 });
  const stats = getOverallStats();
  const attempts = getAttempts().slice(0, 3);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Hero Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-primary/20 via-primary/10 to-accent/10 border border-primary/20 rounded-2xl p-6">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-primary" />
            <span className="text-primary font-semibold text-sm uppercase tracking-wide">VoltPrep</span>
          </div>
          <h2 className="text-2xl font-bold text-foreground">Electrical Engineering Study Platform</h2>
          <p className="text-muted-foreground mt-1 text-sm">Master GATE, SSC-JE, ESE, Diploma & B.Tech with topic-wise practice, mock tests, and formula revision.</p>
          <div className="flex flex-wrap gap-3 mt-4">
            <Link href="/subjects">
              <button data-testid="btn-start-practice" className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                Start Practicing <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
            <Link href="/mock-test">
              <button data-testid="btn-start-mock" className="flex items-center gap-2 px-4 py-2 bg-card border border-border text-foreground rounded-lg text-sm font-medium hover:bg-secondary transition-colors">
                Mock Test <Target className="w-4 h-4" />
              </button>
            </Link>
          </div>
        </div>
        <div className="absolute right-6 top-4 opacity-10">
          <Zap className="w-32 h-32 text-primary" />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard label="Questions Attempted" value={stats.totalAttempted} icon={BookOpen} iconColor="text-primary" iconBg="bg-primary/10" />
        <StatCard label="Accuracy" value={`${stats.accuracy}%`} icon={Trophy} iconColor="text-yellow-500" iconBg="bg-yellow-500/10" />
        <StatCard label="Study Streak" value={`${streak.count}d`} icon={Flame} iconColor="text-orange-500" iconBg="bg-orange-500/10" />
        <StatCard label="Bookmarks" value={bookmarks.length} icon={Bookmark} iconColor="text-blue-500" iconBg="bg-blue-500/10" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Subject Progress */}
        <div className="lg:col-span-2 bg-card border border-card-border rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Subject Progress</h3>
            <Link href="/subjects">
              <span className="text-xs text-primary hover:text-primary/80 cursor-pointer">View all</span>
            </Link>
          </div>
          <div className="space-y-3">
            {SUBJECTS.map(subject => {
              const s = getSubjectStats(subject.id);
              const total = QUESTIONS.filter(q => q.subject === subject.id).length;
              const pct = total > 0 ? Math.round((s.attempted / total) * 100) : 0;
              const acc = s.attempted > 0 ? Math.round((s.correct / s.attempted) * 100) : 0;
              return (
                <div key={subject.id} data-testid={`subject-progress-${subject.id}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={cn('text-sm font-medium', subject.color)}>{subject.name}</span>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{s.attempted}/{total} attempted</span>
                      {s.attempted > 0 && <span className={acc >= 70 ? 'text-green-500' : acc >= 50 ? 'text-yellow-500' : 'text-red-500'}>{acc}% acc</span>}
                    </div>
                  </div>
                  <ProgressBar value={s.attempted} max={total} color={pct >= 70 ? 'bg-green-500' : pct >= 40 ? 'bg-primary' : 'bg-muted-foreground'} height="h-1.5" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">Recent Activity</h3>
            <Link href="/dashboard">
              <span className="text-xs text-primary hover:text-primary/80 cursor-pointer">History</span>
            </Link>
          </div>
          {attempts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No attempts yet</p>
              <p className="text-xs mt-1">Start a quiz to see your history</p>
            </div>
          ) : (
            <div className="space-y-3">
              {attempts.map(a => {
                const acc = a.totalQuestions > 0 ? Math.round((a.correct / a.totalQuestions) * 100) : 0;
                return (
                  <div key={a.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg" data-testid={`recent-attempt-${a.id}`}>
                    <div>
                      <p className="text-sm font-medium text-foreground capitalize">{a.subject === 'mock' ? 'Mock Test' : a.subject.replace(/-/g, ' ')}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-muted-foreground">{a.correct}/{a.totalQuestions} correct</span>
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{formatTime(a.timeTaken)}</span>
                      </div>
                    </div>
                    <div className={cn('text-sm font-bold', acc >= 70 ? 'text-green-500' : acc >= 50 ? 'text-yellow-500' : 'text-red-500')}>
                      {acc}%
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="mt-4 space-y-2">
            <Link href="/subjects">
              <button data-testid="btn-quick-action-subjects" className="w-full flex items-center justify-between px-3 py-2.5 bg-primary/10 text-primary border border-primary/20 rounded-lg text-sm font-medium hover:bg-primary/20 transition-colors">
                <div className="flex items-center gap-2"><BookOpen className="w-4 h-4" /><span>Subject Practice</span></div>
                <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
            <Link href="/dashboard">
              <button data-testid="btn-quick-action-dashboard" className="w-full flex items-center justify-between px-3 py-2.5 bg-secondary border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary/80 transition-colors">
                <div className="flex items-center gap-2"><BarChart3 className="w-4 h-4" /><span>View Analytics</span></div>
                <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
