import { useState, useCallback } from 'react';
import { useRoute, useLocation } from 'wouter';
import { ChevronLeft, ChevronRight, Send, Settings } from 'lucide-react';
import { QuizCard } from '@/components/quiz/QuizCard';
import { QuizTimer } from '@/components/quiz/QuizTimer';
import { useQuiz } from '@/hooks/useQuiz';
import { useBookmarks } from '@/hooks/useBookmarks';
import { useProgress } from '@/hooks/useProgress';
import { QUESTIONS, SUBJECTS } from '@/data/questions';
import type { SubjectId, Difficulty, ExamType } from '@/data/questions';
import { filterQuestions, generateAttemptId, calculateScore } from '@/utils/quiz';
import { saveAttempt, updateStreak } from '@/utils/storage';
import { cn } from '@/lib/utils';

const TIME_OPTIONS = [10, 20, 30] as const;
const COUNT_OPTIONS = [5, 10, 15, 20] as const;
const DIFF_OPTIONS = ['all', 'easy', 'medium', 'hard'] as const;

export default function QuizPage() {
  const [, params] = useRoute('/quiz/:subjectId');
  const [, setLocation] = useLocation();
  const subjectId = params?.subjectId as SubjectId;
  const subject = SUBJECTS.find(s => s.id === subjectId);

  const [configured, setConfigured] = useState(false);
  const [questionCount, setQuestionCount] = useState(10);
  const [timeLimit, setTimeLimit] = useState(20);
  const [difficulty, setDifficulty] = useState<'all' | Difficulty>('all');
  const [examFilter, setExamFilter] = useState<'all' | ExamType>('all');
  const [questions, setQuestions] = useState(QUESTIONS.filter(q => q.subject === subjectId).slice(0, 10));

  const { isBookmarked, toggleBookmark } = useBookmarks();
  const { recordAttempt } = useProgress();

  const handleTimeUp = useCallback(() => {
    submitAndNavigate();
  }, []);

  const quiz = useQuiz({ questions, timeLimitSeconds: timeLimit * 60, onTimeUp: handleTimeUp });

  const submitAndNavigate = useCallback(() => {
    quiz.submitQuiz();
    const scoreData = calculateScore(questions, quiz.answers);
    const timeTaken = quiz.getTimeTaken();
    const id = generateAttemptId();
    const attempt = {
      id, date: new Date().toISOString(), subject: subjectId,
      totalQuestions: questions.length, correct: scoreData.correct, timeTaken,
      answers: questions.map(q => ({
        questionId: q.id,
        selectedIndex: quiz.answers[q.id] ?? -1,
        isCorrect: quiz.answers[q.id] === q.correctIndex,
      })),
    };
    saveAttempt(attempt);
    updateStreak();
    recordAttempt(subjectId, scoreData.correct, questions.length, timeTaken);
    setTimeout(() => setLocation(`/result/${id}`), 400);
  }, [quiz, questions, subjectId, recordAttempt, setLocation]);

  if (!subject) return (
    <div className="flex items-center justify-center h-64 text-muted-foreground">Subject not found</div>
  );

  // Config screen
  if (!configured) {
    return (
      <div className="max-w-lg mx-auto">
        <div className="bg-card border border-card-border rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <Settings className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-bold text-foreground">Configure Quiz</h2>
          </div>
          <div className="text-sm font-semibold text-primary mb-4">{subject.name}</div>

          <div className="space-y-5">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Number of Questions</label>
              <div className="flex gap-2">
                {COUNT_OPTIONS.map(c => (
                  <button key={c} data-testid={`config-count-${c}`} onClick={() => setQuestionCount(c)}
                    className={cn('flex-1 py-2 rounded-lg border text-sm font-medium transition-colors', questionCount === c ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:bg-secondary')}>
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Time Limit (minutes)</label>
              <div className="flex gap-2">
                {TIME_OPTIONS.map(t => (
                  <button key={t} data-testid={`config-time-${t}`} onClick={() => setTimeLimit(t)}
                    className={cn('flex-1 py-2 rounded-lg border text-sm font-medium transition-colors', timeLimit === t ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:bg-secondary')}>
                    {t} min
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Difficulty</label>
              <div className="flex gap-2 flex-wrap">
                {DIFF_OPTIONS.map(d => (
                  <button key={d} data-testid={`config-diff-${d}`} onClick={() => setDifficulty(d)}
                    className={cn('px-3 py-1.5 rounded-lg border text-sm font-medium capitalize transition-colors', difficulty === d ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:bg-secondary')}>
                    {d}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Exam Type</label>
              <div className="flex gap-2 flex-wrap">
                {(['all', 'GATE', 'SSC-JE', 'ESE', 'Diploma', 'B.Tech'] as const).map(e => (
                  <button key={e} data-testid={`config-exam-${e}`} onClick={() => setExamFilter(e)}
                    className={cn('px-3 py-1.5 rounded-lg border text-sm font-medium transition-colors', examFilter === e ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-foreground hover:bg-secondary')}>
                    {e}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            data-testid="btn-start-quiz"
            onClick={() => {
              const filtered = filterQuestions(QUESTIONS, {
                subjects: [subjectId],
                difficulty: difficulty === 'all' ? undefined : difficulty,
                exam: examFilter === 'all' ? undefined : examFilter,
                count: questionCount,
              });
              setQuestions(filtered.length > 0 ? filtered : QUESTIONS.filter(q => q.subject === subjectId).slice(0, questionCount));
              setConfigured(true);
              quiz.startQuiz();
            }}
            className="mt-6 w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors"
          >
            Start Quiz
          </button>
        </div>
      </div>
    );
  }

  const current = quiz.currentQuestion;
  if (!current) return null;

  const answered = Object.keys(quiz.answers).filter(k => quiz.answers[k] !== null).length;

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="font-bold text-foreground">{subject.name}</h2>
          <p className="text-xs text-muted-foreground">{answered}/{questions.length} answered</p>
        </div>
        <QuizTimer timeRemaining={quiz.timeRemaining} totalTime={timeLimit * 60} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Question navigator */}
        <div className="lg:col-span-1">
          <div className="bg-card border border-card-border rounded-xl p-4">
            <p className="text-xs font-medium text-muted-foreground mb-3">Questions</p>
            <div className="grid grid-cols-5 lg:grid-cols-4 gap-1.5">
              {questions.map((q, i) => {
                const isAnswered = quiz.answers[q.id] !== undefined && quiz.answers[q.id] !== null;
                const isMarked = quiz.markedForReview.includes(q.id);
                const isCurrent = quiz.currentIndex === i;
                return (
                  <button
                    key={q.id}
                    data-testid={`nav-question-${i}`}
                    onClick={() => quiz.navigateTo(i)}
                    className={cn(
                      'w-8 h-8 rounded-md text-xs font-semibold transition-colors',
                      isCurrent ? 'ring-2 ring-primary ring-offset-1 ring-offset-card' : '',
                      isMarked ? 'bg-orange-500/20 text-orange-500 border border-orange-500/30' :
                      isAnswered ? 'bg-green-500/20 text-green-500 border border-green-500/30' :
                      'bg-secondary text-muted-foreground border border-border hover:border-primary/50'
                    )}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
            <div className="mt-3 space-y-1">
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="w-3 h-3 rounded bg-green-500/20 border border-green-500/30 inline-block" />Answered</div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="w-3 h-3 rounded bg-orange-500/20 border border-orange-500/30 inline-block" />Marked</div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="w-3 h-3 rounded bg-secondary border border-border inline-block" />Unattempted</div>
            </div>
            {!quiz.isSubmitted && (
              <button
                data-testid="btn-submit-quiz"
                onClick={submitAndNavigate}
                className="mt-4 w-full flex items-center justify-center gap-2 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors"
              >
                <Send className="w-4 h-4" /> Submit
              </button>
            )}
          </div>
        </div>

        {/* Question card */}
        <div className="lg:col-span-3">
          <QuizCard
            question={current}
            questionNumber={quiz.currentIndex + 1}
            totalQuestions={questions.length}
            selectedIndex={quiz.answers[current.id] ?? null}
            isSubmitted={quiz.isSubmitted}
            isMarked={quiz.markedForReview.includes(current.id)}
            isBookmarked={isBookmarked(current.id)}
            onSelect={idx => quiz.selectAnswer(current.id, idx)}
            onToggleMark={() => quiz.toggleMarkForReview(current.id)}
            onToggleBookmark={() => toggleBookmark(current.id)}
          />

          <div className="flex items-center justify-between mt-3">
            <button
              data-testid="btn-prev-question"
              onClick={quiz.prevQuestion}
              disabled={quiz.currentIndex === 0}
              className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4" /> Prev
            </button>
            <span className="text-sm text-muted-foreground">{quiz.currentIndex + 1} / {questions.length}</span>
            <button
              data-testid="btn-next-question"
              onClick={quiz.nextQuestion}
              disabled={quiz.currentIndex === questions.length - 1}
              className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Next <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
