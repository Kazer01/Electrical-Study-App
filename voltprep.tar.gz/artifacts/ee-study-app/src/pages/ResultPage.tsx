import { useRoute, useLocation, Link } from 'wouter';
import { Trophy, Clock, Target, CheckCircle, XCircle, RotateCcw, BarChart3, Bookmark } from 'lucide-react';
import { getAttempts } from '@/utils/storage';
import { QUESTIONS, SUBJECTS } from '@/data/questions';
import type { SubjectId } from '@/data/questions';
import { formatTime, getPerformanceBadge } from '@/utils/quiz';
import { ProgressBar } from '@/components/quiz/ProgressBar';
import { SubjectBadge } from '@/components/shared/SubjectBadge';
import { useBookmarks } from '@/hooks/useBookmarks';
import { cn } from '@/lib/utils';
import { useState } from 'react';

export default function ResultPage() {
  const [, params] = useRoute('/result/:attemptId');
  const [, setLocation] = useLocation();
  const { toggleBookmark, isBookmarked } = useBookmarks();
  const [showAllExplanations, setShowAllExplanations] = useState(false);

  const attemptId = params?.attemptId;
  const attempts = getAttempts();
  const attempt = attempts.find(a => a.id === attemptId);

  if (!attempt) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <p className="text-muted-foreground">Result not found.</p>
        <Link href="/"><button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm">Go Home</button></Link>
      </div>
    );
  }

  const accuracy = attempt.totalQuestions > 0 ? Math.round((attempt.correct / attempt.totalQuestions) * 100) : 0;
  const badge = getPerformanceBadge(accuracy);
  const questions = QUESTIONS.filter(q => attempt.answers.some(a => a.questionId === q.id));

  // Subject breakdown (for mock test)
  const subjectBreakdown = SUBJECTS.map(s => {
    const subjectAnswers = attempt.answers.filter(a => {
      const q = QUESTIONS.find(q => q.id === a.questionId);
      return q?.subject === s.id;
    });
    if (subjectAnswers.length === 0) return null;
    const correct = subjectAnswers.filter(a => a.isCorrect).length;
    return { subject: s, total: subjectAnswers.length, correct, acc: Math.round((correct / subjectAnswers.length) * 100) };
  }).filter(Boolean);

  const wrongAnswers = attempt.answers.filter(a => !a.isCorrect && a.selectedIndex !== -1);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Score header */}
      <div className="bg-gradient-to-br from-primary/15 via-primary/5 to-transparent border border-primary/20 rounded-2xl p-6">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <span className={cn('inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold', badge.bg, badge.color)}>
              <Trophy className="w-4 h-4 mr-1.5" /> {badge.label}
            </span>
            <div className="mt-3">
              <div className="text-5xl font-bold text-foreground">{accuracy}<span className="text-2xl text-muted-foreground">%</span></div>
              <p className="text-muted-foreground mt-1">{attempt.correct} out of {attempt.totalQuestions} correct</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-card/80 border border-border rounded-xl p-3 text-center">
              <CheckCircle className="w-5 h-5 text-green-500 mx-auto mb-1" />
              <div className="text-xl font-bold text-green-500">{attempt.correct}</div>
              <div className="text-xs text-muted-foreground">Correct</div>
            </div>
            <div className="bg-card/80 border border-border rounded-xl p-3 text-center">
              <XCircle className="w-5 h-5 text-red-500 mx-auto mb-1" />
              <div className="text-xl font-bold text-red-500">{attempt.answers.filter(a => !a.isCorrect && a.selectedIndex !== -1).length}</div>
              <div className="text-xs text-muted-foreground">Wrong</div>
            </div>
            <div className="bg-card/80 border border-border rounded-xl p-3 text-center">
              <Target className="w-5 h-5 text-muted-foreground mx-auto mb-1" />
              <div className="text-xl font-bold text-muted-foreground">{attempt.answers.filter(a => a.selectedIndex === -1).length}</div>
              <div className="text-xs text-muted-foreground">Skipped</div>
            </div>
            <div className="bg-card/80 border border-border rounded-xl p-3 text-center">
              <Clock className="w-5 h-5 text-blue-500 mx-auto mb-1" />
              <div className="text-xl font-bold text-blue-500">{formatTime(attempt.timeTaken)}</div>
              <div className="text-xs text-muted-foreground">Time</div>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <ProgressBar value={accuracy} max={100} color={accuracy >= 70 ? 'bg-green-500' : accuracy >= 50 ? 'bg-yellow-500' : 'bg-red-500'} height="h-3" />
        </div>
      </div>

      {/* Subject breakdown (mock test) */}
      {subjectBreakdown.length > 1 && (
        <div className="bg-card border border-card-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-foreground">Subject Breakdown</h3>
          </div>
          <div className="space-y-3">
            {subjectBreakdown.map(s => s && (
              <div key={s.subject.id}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className={cn('text-sm font-medium', s.subject.color)}>{s.subject.name}</span>
                    <span className="text-xs text-muted-foreground">{s.correct}/{s.total}</span>
                  </div>
                  <span className={cn('text-sm font-bold', s.acc >= 70 ? 'text-green-500' : s.acc >= 50 ? 'text-yellow-500' : 'text-red-500')}>{s.acc}%</span>
                </div>
                <ProgressBar value={s.acc} max={100} height="h-1.5" color={s.acc >= 70 ? 'bg-green-500' : s.acc >= 50 ? 'bg-yellow-500' : 'bg-red-500'} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Question-by-question review */}
      <div className="bg-card border border-card-border rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Question Review ({attempt.answers.length})</h3>
          <button
            onClick={() => setShowAllExplanations(s => !s)}
            data-testid="btn-toggle-all-explanations"
            className="text-xs text-primary hover:text-primary/80 border border-primary/30 px-2.5 py-1 rounded-lg transition-colors"
          >
            {showAllExplanations ? 'Hide' : 'Show'} all explanations
          </button>
        </div>
        <div className="space-y-3">
          {attempt.answers.map((ans, i) => {
            const q = QUESTIONS.find(q => q.id === ans.questionId);
            if (!q) return null;
            const isCorrect = ans.isCorrect;
            const isSkipped = ans.selectedIndex === -1;
            return (
              <div key={ans.questionId} data-testid={`result-question-${i}`}
                className={cn('rounded-lg border p-4', isCorrect ? 'border-green-500/30 bg-green-500/5' : isSkipped ? 'border-border bg-secondary/30' : 'border-red-500/30 bg-red-500/5')}>
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-0.5">
                    {isCorrect ? <CheckCircle className="w-4 h-4 text-green-500" /> : isSkipped ? <Target className="w-4 h-4 text-muted-foreground" /> : <XCircle className="w-4 h-4 text-red-500" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-muted-foreground font-medium">Q{i + 1}</span>
                      <SubjectBadge subject={q.subject} size="sm" />
                    </div>
                    <p className="text-sm text-foreground leading-snug">{q.question}</p>
                    <div className="mt-2 space-y-1">
                      {!isSkipped && !isCorrect && (
                        <p className="text-xs text-red-500">Your answer: {['A','B','C','D'][ans.selectedIndex]} — {q.options[ans.selectedIndex]}</p>
                      )}
                      {!isCorrect && <p className="text-xs text-green-500">Correct: {['A','B','C','D'][q.correctIndex]} — {q.options[q.correctIndex]}</p>}
                      {isSkipped && <p className="text-xs text-muted-foreground">Skipped</p>}
                    </div>
                    {(showAllExplanations || !isCorrect) && (
                      <div className="mt-2 p-2.5 bg-blue-500/5 border border-blue-500/20 rounded-lg">
                        <p className="text-xs text-foreground leading-relaxed">{q.explanation}</p>
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => toggleBookmark(q.id)}
                    data-testid={`btn-result-bookmark-${q.id}`}
                    className={cn('p-1.5 rounded flex-shrink-0', isBookmarked(q.id) ? 'text-primary' : 'text-muted-foreground hover:text-foreground')}
                  >
                    <Bookmark className="w-4 h-4" fill={isBookmarked(q.id) ? 'currentColor' : 'none'} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-3">
        <button onClick={() => window.history.back()} data-testid="btn-retry"
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors">
          <RotateCcw className="w-4 h-4" /> Try Again
        </button>
        <Link href="/dashboard">
          <button data-testid="btn-go-dashboard" className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors">
            <BarChart3 className="w-4 h-4" /> Dashboard
          </button>
        </Link>
        {wrongAnswers.length > 0 && (
          <button
            data-testid="btn-bookmark-mistakes"
            onClick={() => wrongAnswers.forEach(a => { if (!isBookmarked(a.questionId)) toggleBookmark(a.questionId); })}
            className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors"
          >
            <Bookmark className="w-4 h-4" /> Bookmark Mistakes
          </button>
        )}
      </div>
    </div>
  );
}
