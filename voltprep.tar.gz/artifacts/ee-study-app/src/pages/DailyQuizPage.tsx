import { useState, useCallback, useMemo } from 'react';
import { useLocation } from 'wouter';
import { CalendarDays, Flame, CheckCircle, XCircle, ChevronLeft, ChevronRight, Send, Trophy, RotateCcw, Sparkles } from 'lucide-react';
import { QuizCard } from '@/components/quiz/QuizCard';
import { QuizTimer } from '@/components/quiz/QuizTimer';
import { ProgressBar } from '@/components/quiz/ProgressBar';
import { useQuiz } from '@/hooks/useQuiz';
import { useBookmarks } from '@/hooks/useBookmarks';
import { useProgress } from '@/hooks/useProgress';
import { QUESTIONS } from '@/data/questions';
import type { SubjectId } from '@/data/questions';
import { calculateScore, formatTime, getPerformanceBadge } from '@/utils/quiz';
import {
  getDailyQuestions, getDailyResult, saveDailyResult,
  getDailyStreak, getWeeklyDailyHistory, getTodayKey,
} from '@/utils/dailyQuiz';
import { cn } from '@/lib/utils';

const DAILY_TIME_LIMIT = 10 * 60; // 10 minutes

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function DailyQuizPage() {
  const [, setLocation] = useLocation();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const { recordAttempt } = useProgress();

  const todayKey = getTodayKey();
  const existingResult = getDailyResult();
  const streak = getDailyStreak();
  const weeklyHistory = getWeeklyDailyHistory();

  const dailyQuestions = useMemo(() => getDailyQuestions(QUESTIONS), []);
  const [started, setStarted] = useState(false);
  const [showResult, setShowResult] = useState(!!existingResult);

  const handleTimeUp = useCallback(() => doFinish(), []);

  const quiz = useQuiz({
    questions: dailyQuestions,
    timeLimitSeconds: DAILY_TIME_LIMIT,
    onTimeUp: handleTimeUp,
  });

  const doFinish = useCallback(() => {
    quiz.submitQuiz();
    const score = calculateScore(dailyQuestions, quiz.answers);
    const timeTaken = quiz.getTimeTaken();

    const result = {
      date: todayKey,
      correct: score.correct,
      total: dailyQuestions.length,
      timeTaken,
      answers: dailyQuestions.map(q => ({
        questionId: q.id,
        selectedIndex: quiz.answers[q.id] ?? -1,
        isCorrect: quiz.answers[q.id] === q.correctIndex,
      })),
    };
    saveDailyResult(result);

    const subjectGroups: Partial<Record<SubjectId, { correct: number; total: number }>> = {};
    for (const q of dailyQuestions) {
      if (!subjectGroups[q.subject]) subjectGroups[q.subject] = { correct: 0, total: 0 };
      subjectGroups[q.subject]!.total++;
      if (quiz.answers[q.id] === q.correctIndex) subjectGroups[q.subject]!.correct++;
    }
    for (const [subj, data] of Object.entries(subjectGroups)) {
      if (data) recordAttempt(subj as SubjectId, data.correct, data.total, 0);
    }
    setShowResult(true);
  }, [quiz, dailyQuestions, todayKey, recordAttempt]);

  const resultData = existingResult ?? {
    correct: calculateScore(dailyQuestions, quiz.answers).correct,
    total: dailyQuestions.length,
    timeTaken: quiz.getTimeTaken(),
    answers: dailyQuestions.map(q => ({
      questionId: q.id,
      selectedIndex: quiz.answers[q.id] ?? -1,
      isCorrect: quiz.answers[q.id] === q.correctIndex,
    })),
  };

  const accuracy = resultData.total > 0 ? Math.round((resultData.correct / resultData.total) * 100) : 0;
  const badge = getPerformanceBadge(accuracy);

  // ── RESULT VIEW ──────────────────────────────────────────────
  if (showResult) {
    return (
      <div className="max-w-2xl mx-auto space-y-5">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 border border-primary/20 rounded-full text-primary text-sm font-medium mb-3">
            <CalendarDays className="w-4 h-4" />
            Daily Quiz — {new Date(todayKey + 'T12:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}
          </div>
          <h2 className="text-2xl font-bold text-foreground">
            {existingResult ? "Today's quiz already completed!" : 'Quiz Complete!'}
          </h2>
        </div>

        {/* Score card */}
        <div className="bg-card border border-card-border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className={cn('inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-sm font-semibold', badge.bg, badge.color)}>
                <Trophy className="w-3.5 h-3.5" /> {badge.label}
              </div>
              <div className="mt-2 text-4xl font-bold text-foreground">{accuracy}<span className="text-xl text-muted-foreground">%</span></div>
              <p className="text-muted-foreground text-sm">{resultData.correct}/{resultData.total} correct · {formatTime(resultData.timeTaken)}</p>
            </div>
            <div className="flex items-center gap-2 px-4 py-3 bg-orange-500/10 border border-orange-500/20 rounded-xl">
              <Flame className="w-6 h-6 text-orange-500" />
              <div>
                <div className="text-2xl font-bold text-orange-500">{streak.count}</div>
                <div className="text-xs text-muted-foreground">day streak</div>
              </div>
            </div>
          </div>
          <ProgressBar value={accuracy} max={100} height="h-3"
            color={accuracy >= 80 ? 'bg-green-500' : accuracy >= 60 ? 'bg-yellow-500' : 'bg-red-500'} />
        </div>

        {/* 7-day calendar */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4">Last 7 Days</h3>
          <div className="grid grid-cols-7 gap-2">
            {weeklyHistory.map((day, i) => {
              const d = new Date(day.date + 'T12:00:00');
              const dayLabel = DAY_LABELS[d.getDay()];
              const isToday = day.date === todayKey;
              const acc = day.total > 0 ? Math.round((day.correct / day.total) * 100) : 0;
              return (
                <div key={day.date} className="flex flex-col items-center gap-1.5">
                  <span className="text-xs text-muted-foreground">{dayLabel}</span>
                  <div className={cn(
                    'w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold border-2',
                    isToday && day.completed ? 'border-primary bg-primary/10 text-primary' :
                    day.completed ? (acc >= 80 ? 'border-green-500 bg-green-500/10 text-green-500' : acc >= 60 ? 'border-yellow-500 bg-yellow-500/10 text-yellow-500' : 'border-red-500 bg-red-500/10 text-red-500') :
                    isToday ? 'border-primary/40 bg-primary/5 text-primary/50' :
                    'border-border bg-secondary/30 text-muted-foreground/40'
                  )}>
                    {day.completed ? (acc >= 60 ? '✓' : '✗') : (isToday ? '·' : '—')}
                  </div>
                  {day.completed && (
                    <span className="text-xs text-muted-foreground">{acc}%</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Question review */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4">Question Review</h3>
          <div className="space-y-3">
            {resultData.answers.map((ans, i) => {
              const q = QUESTIONS.find(q => q.id === ans.questionId);
              if (!q) return null;
              return (
                <div key={ans.questionId} className={cn('rounded-lg border p-3.5', ans.isCorrect ? 'border-green-500/30 bg-green-500/5' : ans.selectedIndex === -1 ? 'border-border bg-secondary/30' : 'border-red-500/30 bg-red-500/5')}>
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-0.5">
                      {ans.isCorrect ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground mb-1">Q{i + 1}</p>
                      <p className="text-sm text-foreground font-medium leading-snug">{q.question}</p>
                      {!ans.isCorrect && ans.selectedIndex !== -1 && (
                        <p className="text-xs text-red-500 mt-1">Your: {['A','B','C','D'][ans.selectedIndex]}</p>
                      )}
                      <p className="text-xs text-green-500 mt-0.5">Correct: {['A','B','C','D'][q.correctIndex]} — {q.options[q.correctIndex]}</p>
                      <p className="text-xs text-muted-foreground mt-2 leading-relaxed border-t border-border/50 pt-2">{q.explanation}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          <button onClick={() => setLocation('/subjects')} data-testid="btn-daily-result-subjects"
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors">
            Continue Practicing
          </button>
          <button onClick={() => setLocation('/dashboard')} data-testid="btn-daily-result-dashboard"
            className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors">
            View Dashboard
          </button>
        </div>
      </div>
    );
  }

  // ── INTRO SCREEN ─────────────────────────────────────────────
  if (!started) {
    const newStreak = streak.lastDate === todayKey ? streak.count : (
      (() => {
        const yesterday = new Date(); yesterday.setDate(yesterday.getDate() - 1);
        return streak.lastDate === yesterday.toISOString().split('T')[0] ? streak.count + 1 : 1;
      })()
    );

    return (
      <div className="max-w-xl mx-auto space-y-4">
        {/* Today card */}
        <div className="bg-gradient-to-br from-primary/20 via-primary/10 to-accent/5 border border-primary/20 rounded-2xl p-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/20 border border-primary/30 rounded-full text-primary text-sm font-medium mb-4">
            <CalendarDays className="w-4 h-4" />
            {new Date(todayKey + 'T12:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </div>
          <h2 className="text-2xl font-bold text-foreground">Daily Quiz</h2>
          <p className="text-muted-foreground text-sm mt-1">5 fresh questions · 10 minute timer · New set every day</p>

          <div className="flex items-center justify-center gap-6 mt-5">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">5</div>
              <div className="text-xs text-muted-foreground mt-0.5">Questions</div>
            </div>
            <div className="w-px h-8 bg-border" />
            <div className="text-center">
              <div className="text-3xl font-bold text-accent">10</div>
              <div className="text-xs text-muted-foreground mt-0.5">Minutes</div>
            </div>
            <div className="w-px h-8 bg-border" />
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-1">
                <Flame className="w-5 h-5 text-orange-500" />
                <span className="text-3xl font-bold text-orange-500">{newStreak}</span>
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">Day streak</div>
            </div>
          </div>
        </div>

        {/* 7-day history preview */}
        <div className="bg-card border border-card-border rounded-xl p-5">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-muted-foreground" /> Last 7 Days
          </h3>
          <div className="grid grid-cols-7 gap-2">
            {weeklyHistory.map(day => {
              const d = new Date(day.date + 'T12:00:00');
              const dayLabel = DAY_LABELS[d.getDay()];
              const isToday = day.date === todayKey;
              return (
                <div key={day.date} className="flex flex-col items-center gap-1">
                  <span className="text-xs text-muted-foreground">{dayLabel}</span>
                  <div className={cn(
                    'w-8 h-8 rounded-lg flex items-center justify-center border-2',
                    isToday ? 'border-primary bg-primary/10' :
                    day.completed ? 'border-green-500 bg-green-500/10' :
                    'border-border bg-secondary/30'
                  )}>
                    {day.completed ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : isToday ? (
                      <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    ) : (
                      <span className="w-1.5 h-1.5 bg-muted-foreground/30 rounded-full" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* AI badge */}
        <div className="flex items-center gap-3 px-4 py-3 bg-purple-500/5 border border-purple-500/20 rounded-xl">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex-shrink-0">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <p className="text-sm text-purple-300/90">AI Explanations are available after each question is answered.</p>
        </div>

        <button
          data-testid="btn-start-daily-quiz"
          onClick={() => { setStarted(true); quiz.startQuiz(); }}
          className="w-full py-3.5 bg-primary text-primary-foreground rounded-xl font-semibold text-base hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
        >
          Start Today's Quiz
        </button>
      </div>
    );
  }

  // ── QUIZ SCREEN ───────────────────────────────────────────────
  const current = quiz.currentQuestion;
  if (!current) return null;
  const answered = Object.values(quiz.answers).filter(a => a !== null && a !== undefined).length;

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-primary" />
            <h2 className="font-bold text-foreground">Daily Quiz</h2>
            <div className="flex items-center gap-1 px-2 py-0.5 bg-orange-500/10 rounded-full">
              <Flame className="w-3 h-3 text-orange-500" />
              <span className="text-xs font-bold text-orange-500">{streak.count}</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">{answered}/{dailyQuestions.length} answered</p>
        </div>
        <QuizTimer timeRemaining={quiz.timeRemaining} totalTime={DAILY_TIME_LIMIT} />
      </div>

      {/* Progress dots */}
      <div className="flex items-center gap-1.5">
        {dailyQuestions.map((q, i) => {
          const isAnswered = quiz.answers[q.id] !== undefined && quiz.answers[q.id] !== null;
          const isCurrent = quiz.currentIndex === i;
          return (
            <button
              key={q.id}
              data-testid={`daily-nav-${i}`}
              onClick={() => quiz.navigateTo(i)}
              className={cn(
                'flex-1 h-2 rounded-full transition-all',
                isCurrent ? 'bg-primary ring-2 ring-primary/30' :
                isAnswered ? 'bg-green-500' :
                'bg-border hover:bg-muted-foreground/40'
              )}
            />
          );
        })}
      </div>

      {/* Question card */}
      <QuizCard
        question={current}
        questionNumber={quiz.currentIndex + 1}
        totalQuestions={dailyQuestions.length}
        selectedIndex={quiz.answers[current.id] ?? null}
        isSubmitted={quiz.isSubmitted}
        isMarked={quiz.markedForReview.includes(current.id)}
        isBookmarked={isBookmarked(current.id)}
        onSelect={idx => quiz.selectAnswer(current.id, idx)}
        onToggleMark={() => quiz.toggleMarkForReview(current.id)}
        onToggleBookmark={() => toggleBookmark(current.id)}
      />

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <button
          data-testid="btn-daily-prev"
          onClick={quiz.prevQuestion}
          disabled={quiz.currentIndex === 0}
          className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >
          <ChevronLeft className="w-4 h-4" /> Prev
        </button>

        {quiz.currentIndex < dailyQuestions.length - 1 ? (
          <button
            data-testid="btn-daily-next"
            onClick={quiz.nextQuestion}
            className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-secondary transition-colors"
          >
            Next <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            data-testid="btn-daily-submit"
            onClick={doFinish}
            disabled={quiz.isSubmitted}
            className="flex items-center gap-2 px-5 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition-colors"
          >
            <Send className="w-4 h-4" /> Submit
          </button>
        )}
      </div>
    </div>
  );
}
