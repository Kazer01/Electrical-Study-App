import type { Question, SubjectId, Difficulty, ExamType } from '../data/questions';

export function shuffleArray<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function calculateScore(
  questions: Question[],
  answers: Record<string, number | null>
): { correct: number; wrong: number; skipped: number; accuracy: number } {
  let correct = 0, wrong = 0, skipped = 0;
  for (const q of questions) {
    const ans = answers[q.id];
    if (ans === null || ans === undefined) skipped++;
    else if (ans === q.correctIndex) correct++;
    else wrong++;
  }
  const attempted = correct + wrong;
  const accuracy = attempted > 0 ? Math.round((correct / attempted) * 100) : 0;
  return { correct, wrong, skipped, accuracy };
}

export function formatTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function generateAttemptId(): string {
  return `attempt_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function filterQuestions(
  questions: Question[],
  filters: {
    subjects?: SubjectId[];
    difficulty?: Difficulty | 'all';
    exam?: ExamType | 'all';
    count?: number;
    ids?: string[];
  }
): Question[] {
  let result = [...questions];
  if (filters.ids && filters.ids.length > 0) {
    result = result.filter(q => filters.ids!.includes(q.id));
  }
  if (filters.subjects && filters.subjects.length > 0) {
    result = result.filter(q => filters.subjects!.includes(q.subject));
  }
  if (filters.difficulty && filters.difficulty !== 'all') {
    result = result.filter(q => q.difficulty === filters.difficulty);
  }
  if (filters.exam && filters.exam !== 'all') {
    result = result.filter(q => q.exam.includes(filters.exam as ExamType));
  }
  result = shuffleArray(result);
  if (filters.count && filters.count > 0) {
    result = result.slice(0, filters.count);
  }
  return result;
}

export function getPerformanceBadge(accuracy: number): {
  label: string;
  color: string;
  bg: string;
} {
  if (accuracy >= 85) return { label: 'Excellent', color: 'text-green-700 dark:text-green-400', bg: 'bg-green-100 dark:bg-green-900/30' };
  if (accuracy >= 70) return { label: 'Good', color: 'text-blue-700 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-900/30' };
  if (accuracy >= 50) return { label: 'Average', color: 'text-yellow-700 dark:text-yellow-400', bg: 'bg-yellow-100 dark:bg-yellow-900/30' };
  return { label: 'Needs Improvement', color: 'text-red-700 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-900/30' };
}
