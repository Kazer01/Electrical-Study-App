import type { Question } from '../data/questions';

const DAILY_QUIZ_COUNT = 5;
const STORAGE_PREFIX = 'ee_daily_';

export interface DailyQuizResult {
  date: string;
  correct: number;
  total: number;
  timeTaken: number;
  answers: { questionId: string; selectedIndex: number; isCorrect: boolean }[];
}

export function getTodayKey(): string {
  return new Date().toISOString().split('T')[0]; // YYYY-MM-DD
}

/** Deterministic seeded shuffle — same date always returns same order */
function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

function dateToSeed(dateStr: string): number {
  return dateStr.split('-').reduce((acc, n) => acc * 100 + parseInt(n, 10), 0);
}

export function getDailyQuestions(allQuestions: Question[]): Question[] {
  const today = getTodayKey();
  const seed = dateToSeed(today);
  const rand = seededRandom(seed);

  const shuffled = [...allQuestions].sort(() => rand() - 0.5);
  return shuffled.slice(0, DAILY_QUIZ_COUNT);
}

export function getDailyResult(): DailyQuizResult | null {
  try {
    const key = `${STORAGE_PREFIX}${getTodayKey()}`;
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveDailyResult(result: DailyQuizResult): void {
  try {
    const key = `${STORAGE_PREFIX}${result.date}`;
    localStorage.setItem(key, JSON.stringify(result));
    updateDailyStreak(result.date);
  } catch {
    /* silently swallow quota errors */
  }
}

export function getDailyStreak(): { count: number; lastDate: string } {
  try {
    const raw = localStorage.getItem('ee_daily_streak');
    return raw ? JSON.parse(raw) : { count: 0, lastDate: '' };
  } catch {
    return { count: 0, lastDate: '' };
  }
}

function updateDailyStreak(date: string): void {
  try {
    const streak = getDailyStreak();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    if (streak.lastDate === date) return;
    const newCount = streak.lastDate === yesterdayStr ? streak.count + 1 : 1;
    localStorage.setItem('ee_daily_streak', JSON.stringify({ count: newCount, lastDate: date }));
  } catch {
    /* silently swallow */
  }
}

export function getWeeklyDailyHistory(): { date: string; completed: boolean; correct: number; total: number }[] {
  const results: { date: string; completed: boolean; correct: number; total: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    try {
      const raw = localStorage.getItem(`${STORAGE_PREFIX}${dateStr}`);
      const result: DailyQuizResult | null = raw ? JSON.parse(raw) : null;
      results.push({
        date: dateStr,
        completed: !!result,
        correct: result?.correct ?? 0,
        total: result?.total ?? DAILY_QUIZ_COUNT,
      });
    } catch {
      results.push({ date: dateStr, completed: false, correct: 0, total: DAILY_QUIZ_COUNT });
    }
  }
  return results;
}
