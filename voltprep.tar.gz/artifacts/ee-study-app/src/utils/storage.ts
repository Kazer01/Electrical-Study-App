export const STORAGE_KEYS = {
  PROGRESS: 'ee_progress',
  BOOKMARKS: 'ee_bookmarks',
  HISTORY: 'ee_history',
  THEME: 'ee_theme',
  STREAK: 'ee_streak',
  MOCK_SCORES: 'ee_mock_scores',
};

export interface QuizAttempt {
  id: string;
  date: string;
  subject: string | 'mock';
  totalQuestions: number;
  correct: number;
  timeTaken: number;
  answers: { questionId: string; selectedIndex: number; isCorrect: boolean }[];
}

export interface Streak {
  lastDate: string;
  count: number;
}

export function saveAttempt(attempt: QuizAttempt): void {
  try {
    const historyJson = localStorage.getItem(STORAGE_KEYS.HISTORY);
    const history: QuizAttempt[] = historyJson ? JSON.parse(historyJson) : [];
    history.unshift(attempt);
    if (history.length > 50) history.length = 50; // Keep last 50
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
  } catch (e) {
    console.error('Failed to save attempt', e);
  }
}

export function getAttempts(): QuizAttempt[] {
  try {
    const historyJson = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return historyJson ? JSON.parse(historyJson) : [];
  } catch (e) {
    return [];
  }
}

export function updateStreak(): void {
  try {
    const today = new Date().toISOString().split('T')[0];
    const streakJson = localStorage.getItem(STORAGE_KEYS.STREAK);
    let streak: Streak = streakJson ? JSON.parse(streakJson) : { lastDate: '', count: 0 };

    if (streak.lastDate === today) {
      // Already updated today
      return;
    }

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    if (streak.lastDate === yesterdayStr) {
      streak.count += 1;
    } else {
      streak.count = 1;
    }

    streak.lastDate = today;
    localStorage.setItem(STORAGE_KEYS.STREAK, JSON.stringify(streak));
  } catch (e) {
    console.error('Failed to update streak', e);
  }
}
