import { Router } from "express";
import { openai } from "@workspace/integrations-openai-ai-server";
import { ExplainQuestionBody } from "@workspace/api-zod";

const router = Router();

router.post("/explain", async (req, res) => {
  const parseResult = ExplainQuestionBody.safeParse(req.body);
  if (!parseResult.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { question, options, correctIndex, subject, difficulty, exam, existingExplanation } =
    parseResult.data;

  const correctOption = options[correctIndex] ?? "";
  const optionsList = options.map((o, i) => `${String.fromCharCode(65 + i)}) ${o}`).join("\n");

  const systemPrompt = `You are an expert Electrical Engineering tutor helping students prepare for competitive exams like GATE, SSC-JE, ESE, and B.Tech. Your explanations are clear, concise, and exam-focused.`;

  const userPrompt = `Explain the following multiple-choice question in detail.

Subject: ${subject}
Difficulty: ${difficulty}
Exams: ${exam.join(", ")}

Question: ${question}

Options:
${optionsList}

Correct Answer: ${String.fromCharCode(65 + correctIndex)}) ${correctOption}

Existing explanation (use this as a starting point but enhance it):
${existingExplanation}

Please provide:
1. **Core Concept** – The fundamental principle this question tests (2-3 sentences)
2. **Step-by-Step Solution** – How to arrive at the correct answer
3. **Why Other Options Are Wrong** – Brief reason for each incorrect option
4. **Exam Tip** – A quick memory aid or pattern to remember for this type of question in ${exam[0] ?? "competitive"} exams

Keep the total response under 350 words. Use markdown formatting.`;

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-5.4",
      max_completion_tokens: 1024,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "OpenAI explain error");
    res.write(`data: ${JSON.stringify({ error: "AI service unavailable. Please try again." })}\n\n`);
    res.end();
  }
});

export default router;
